import { pgTable, serial, numeric, text } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const appSettingsTable = pgTable("app_settings", {
  id: serial("id").primaryKey(),
  referralCommissionPercent: numeric("referral_commission_percent", { precision: 5, scale: 2 }).notNull().default("5"),
  minWithdrawal: numeric("min_withdrawal", { precision: 10, scale: 2 }).notNull().default("50"),
  appName: text("app_name").notNull().default("Earn Space"),
  primaryColor: text("primary_color").notNull().default("#e11d48"),
  logoText: text("logo_text").notNull().default("E"),
  appDownloadUrl: text("app_download_url"),
  telegramUrl: text("telegram_url"),
  whatsappUrl: text("whatsapp_url"),
  referralFirstTaskBonus: numeric("referral_first_task_bonus", { precision: 10, scale: 2 }).notNull().default("10"),
  level2CommissionPercent: numeric("level2_commission_percent", { precision: 5, scale: 2 }).notNull().default("5"),
});

export const insertAppSettingsSchema = createInsertSchema(appSettingsTable).omit({ id: true });
export type InsertAppSettings = z.infer<typeof insertAppSettingsSchema>;
export type AppSettings = typeof appSettingsTable.$inferSelect;
