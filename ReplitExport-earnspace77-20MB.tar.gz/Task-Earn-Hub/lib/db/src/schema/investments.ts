import { createInsertSchema } from "drizzle-zod";
import { integer, numeric, pgEnum, pgTable, serial, text, timestamp, boolean, uniqueIndex } from "drizzle-orm/pg-core";
import { usersTable } from "./users";
import { z } from "zod/v4";

export const investmentStatusEnum = pgEnum("investment_status", ["fundraising", "active", "matured", "refunded"]);
export const investmentPlanFundingStatusEnum = pgEnum("investment_plan_funding_status", ["fundraising", "active", "cancelled"]);

export const investmentPlansTable = pgTable("investment_plans", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  description: text("description").notNull().default(""),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  targetAmount: numeric("target_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  minimumInvestment: numeric("minimum_investment", { precision: 12, scale: 2 }).notNull().default("0"),
  termDays: integer("term_days").notNull(),
  ratePercent: numeric("rate_percent", { precision: 7, scale: 2 }).notNull(),
  ratePeriodDays: integer("rate_period_days").notNull(),
  active: boolean("active").notNull().default(true),
  fundingStatus: investmentPlanFundingStatusEnum("funding_status").notNull().default("fundraising"),
  activatedAt: timestamp("activated_at", { withTimezone: true }),
  cancelledAt: timestamp("cancelled_at", { withTimezone: true }),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const investmentsTable = pgTable("investments", {
  id: serial("id").primaryKey(),
  userId: integer("user_id").notNull().references(() => usersTable.id),
  planId: integer("plan_id").notNull().references(() => investmentPlansTable.id),
  planTitle: text("plan_title").notNull(),
  principal: numeric("principal", { precision: 12, scale: 2 }).notNull(),
  estimatedProfit: numeric("estimated_profit", { precision: 12, scale: 2 }).notNull(),
  totalReturn: numeric("total_return", { precision: 12, scale: 2 }).notNull(),
  termDays: integer("term_days").notNull(),
  ratePercent: numeric("rate_percent", { precision: 7, scale: 2 }).notNull(),
  ratePeriodDays: integer("rate_period_days").notNull(),
  status: investmentStatusEnum("status").notNull().default("active"),
  idempotencyKey: text("idempotency_key").notNull(),
  investedAt: timestamp("invested_at", { withTimezone: true }).notNull().defaultNow(),
  activationAt: timestamp("activation_at", { withTimezone: true }),
  maturityAt: timestamp("maturity_at", { withTimezone: true }),
  settledAt: timestamp("settled_at", { withTimezone: true }),
  refundedAt: timestamp("refunded_at", { withTimezone: true }),
}, (table) => [
  uniqueIndex("investments_idempotency_key_unique").on(table.idempotencyKey),
]);

export const insertInvestmentPlanSchema = createInsertSchema(investmentPlansTable).omit({
  id: true,
  createdAt: true,
});
export type InsertInvestmentPlan = z.infer<typeof insertInvestmentPlanSchema>;
export type InvestmentPlan = typeof investmentPlansTable.$inferSelect;
export type Investment = typeof investmentsTable.$inferSelect;