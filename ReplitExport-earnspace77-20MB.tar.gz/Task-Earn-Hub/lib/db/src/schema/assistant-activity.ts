import { pgTable, text, serial, timestamp, integer } from "drizzle-orm/pg-core";
import { usersTable } from "./users";

export const assistantActivityTable = pgTable("assistant_activity", {
  id: serial("id").primaryKey(),
  assistantId: integer("assistant_id").notNull().references(() => usersTable.id),
  action: text("action").notNull(),
  taskId: integer("task_id"),
  submissionId: integer("submission_id"),
  details: text("details"),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export type AssistantActivity = typeof assistantActivityTable.$inferSelect;