---
name: Investment group compatibility
description: Legacy fixed investment plans and positions must remain distinct from new target-funded groups.
---

When target-funded group plans coexist with older fixed-plan records:

- Treat missing or zero target/minimum values as the legacy plan amount so old plans still have valid funding thresholds.
- Do not count legacy active or matured positions as group contributions; group positions are identified by their fundraising state or a non-null activation time. Refunded group contributions remain in historical progress for cancelled plans.

**Why:** Existing investments must keep their original payout schedule, and legacy positions must not prematurely fill a new group target or inflate its participant count.

**How to apply:** Preserve this distinction when changing plan backfills, contribution aggregation, or investment lifecycle states; verify both old positions and new group contributions.