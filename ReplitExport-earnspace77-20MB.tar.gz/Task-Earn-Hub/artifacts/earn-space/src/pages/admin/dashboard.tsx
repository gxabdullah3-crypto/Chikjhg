import { useGetAdminStats } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { ClipboardList, DollarSign, TrendingUp, Users, CheckSquare, Wallet } from "lucide-react";

export default function AdminDashboard() {
  const { data: stats } = useGetAdminStats();

  const statCards = [
    { label: "মোট ইউজার", value: stats?.totalUsers ?? 0, icon: Users, suffix: "জন", tone: "blue" },
    { label: "মোট টাস্ক", value: stats?.totalTasks ?? 0, icon: CheckSquare, suffix: "টি", tone: "green" },
    { label: "অপেক্ষমান সাবমিশন", value: stats?.pendingSubmissions ?? 0, icon: ClipboardList, suffix: "টি", tone: "gold" },
    { label: "অপেক্ষমান উইথড্রয়াল", value: stats?.pendingWithdrawals ?? 0, icon: Wallet, suffix: "টি", tone: "rose" },
    { label: "মোট পরিশোধ", value: `৳${(stats?.totalPaid ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, icon: TrendingUp, tone: "green" },
    { label: "মোট ইউজার ব্যালেন্স", value: `৳${(stats?.totalBalance ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`, icon: DollarSign, tone: "gold", featured: true },
  ];

  return (
    <div className="mx-auto max-w-7xl space-y-6 pb-8" data-testid="page-admin-dashboard">
      <header className="space-y-2">
        <p className="dashboard-section-label mb-0">Administration</p>
        <h1>অ্যাডমিন ড্যাশবোর্ড</h1>
        <p className="max-w-2xl text-sm leading-6 text-muted-foreground">প্ল্যাটফর্মের বর্তমান কার্যক্রম এবং সার্বিক পরিসংখ্যান এক নজরে দেখুন।</p>
      </header>

      <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3" aria-label="প্ল্যাটফর্মের সারাংশ">
        {statCards.map((card) => (
          <Card
            key={card.label}
            className={`admin-metric-card ${card.featured ? "is-featured" : ""}`}
            data-tone={card.tone}
          >
            <CardHeader className="flex-row items-center justify-between space-y-0 pb-3">
              <CardTitle className="text-sm font-medium text-muted-foreground">{card.label}</CardTitle>
              <span className="admin-metric-icon">
                <card.icon className="h-[18px] w-[18px]" strokeWidth={1.8} />
              </span>
            </CardHeader>
            <CardContent>
              <p className="admin-metric-value">{card.value}</p>
              {card.suffix && <p className="mt-1 text-xs text-muted-foreground">{card.suffix}</p>}
            </CardContent>
          </Card>
        ))}
      </section>
    </div>
  );
}