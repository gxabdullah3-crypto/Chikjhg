import { useState } from "react";
import {
  useGetMe,
  useListTasks,
  useCreateTask,
  useUpdateTask,
  useDeleteTask,
  getListTasksQueryKey,
} from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { Pencil, Trash2, Plus, Link } from "lucide-react";

function getApiErrorMessage(error: unknown, fallback: string) {
  const apiError = error as {
    data?: { error?: string };
    response?: { data?: { error?: string } };
  };
  return apiError.data?.error || apiError.response?.data?.error || fallback;
}

export default function AdminTasks() {
  const queryClient = useQueryClient();
  const { data: tasks, isLoading: tasksLoading, isError: tasksError, refetch: refetchTasks } = useListTasks();
  const { data: currentUser } = useGetMe();
  const createTask = useCreateTask();
  const updateTask = useUpdateTask();
  const deleteTask = useDeleteTask();
  const { toast } = useToast();
  const isAssistant = currentUser?.role === "assistant";

  const [isOpen, setIsOpen] = useState(false);
  const [editingId, setEditingId] = useState<number | null>(null);
  const [deleteId, setDeleteId] = useState<number | null>(null);

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [reward, setReward] = useState("");
  const [link, setLink] = useState("");
  const [status, setStatus] = useState("active");

  const resetForm = () => {
    setTitle(""); setDescription(""); setReward(""); setLink(""); setStatus("active"); setEditingId(null);
  };

  const invalidateTasks = () => queryClient.invalidateQueries({ queryKey: getListTasksQueryKey() });

  const handleEdit = (task: NonNullable<typeof tasks>[number]) => {
    setTitle(task.title);
    setDescription(task.description);
    setReward(task.reward.toString());
    setLink(task.link || "");
    setStatus(task.status);
    setEditingId(task.id);
    setIsOpen(true);
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const data = {
      title,
      description,
      reward: parseFloat(reward),
      link: link.trim() || null,
      status,
    };

    if (editingId) {
      updateTask.mutate(
        { id: editingId, data },
        {
          onSuccess: () => {
            toast({ title: "টাস্ক আপডেট হয়েছে" });
            setIsOpen(false);
            resetForm();
            invalidateTasks();
          },
          onError: (error: unknown) => toast({
            title: "ব্যর্থ হয়েছে",
            description: getApiErrorMessage(error, "আবার চেষ্টা করুন।"),
            variant: "destructive",
          }),
        }
      );
    } else {
      createTask.mutate(
        { data },
        {
          onSuccess: () => {
            toast({ title: "টাস্ক তৈরি হয়েছে" });
            setIsOpen(false);
            resetForm();
            invalidateTasks();
          },
          onError: (error: unknown) => toast({
            title: "ব্যর্থ হয়েছে",
            description: getApiErrorMessage(error, "আবার চেষ্টা করুন।"),
            variant: "destructive",
          }),
        }
      );
    }
  };

  const handleDelete = () => {
    if (!deleteId) return;
    deleteTask.mutate(
      { id: deleteId },
      {
        onSuccess: () => {
          toast({ title: "টাস্ক মুছে গেছে" });
          setDeleteId(null);
          invalidateTasks();
        },
        onError: (error: unknown) => toast({
          title: "মুছতে পারেনি",
          description: getApiErrorMessage(error, "আবার চেষ্টা করুন।"),
          variant: "destructive",
        }),
      }
    );
  };

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-bold tracking-tight">টাস্ক ম্যানেজ</h1>
          <p className="text-muted-foreground mt-1">
            {isAssistant ? "আপনার তৈরি টাস্ক পোস্ট ও পরিচালনা করুন।" : "নতুন টাস্ক তৈরি করুন বা পুরানো এডিট করুন।"}
          </p>
        </div>
        <Dialog open={isOpen} onOpenChange={(open) => { setIsOpen(open); if (!open) resetForm(); }}>
          <DialogTrigger asChild>
            <Button data-testid="button-create-task" className="gap-2">
              <Plus className="h-4 w-4" />
              নতুন টাস্ক
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[550px]">
            <DialogHeader>
              <DialogTitle>{editingId ? "টাস্ক এডিট" : "নতুন টাস্ক তৈরি"}</DialogTitle>
            </DialogHeader>
            <form onSubmit={handleSubmit} className="space-y-4 pt-2">
              <div className="space-y-2">
                <Label>শিরোনাম</Label>
                <Input
                  data-testid="input-task-title"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                  placeholder="টাস্কের নাম"
                  required
                />
              </div>
              <div className="space-y-2">
                <Label>বিবরণ</Label>
                <Textarea
                  data-testid="input-task-description"
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  placeholder="কাজটি কীভাবে করতে হবে তার বিস্তারিত লিখুন..."
                  rows={4}
                  required
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>পুরস্কার (BDT)</Label>
                  <Input
                    data-testid="input-task-reward"
                    type="number"
                    step="0.01"
                    min="0.01"
                    value={reward}
                    onChange={(e) => setReward(e.target.value)}
                    placeholder="10.00"
                    required
                  />
                </div>
                <div className="space-y-2">
                  <Label>স্ট্যাটাস</Label>
                  <Select value={status} onValueChange={setStatus}>
                    <SelectTrigger data-testid="select-task-status">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="active">সক্রিয়</SelectItem>
                      <SelectItem value="inactive">নিষ্ক্রিয়</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <div className="space-y-2">
                <Label>লিংক (ঐচ্ছিক)</Label>
                <Input
                  data-testid="input-task-link"
                  type="url"
                  value={link}
                  onChange={(e) => setLink(e.target.value)}
                  placeholder="https://example.com"
                />
                <p className="text-xs text-muted-foreground">টাস্ক পেজে এই লিংক সরাসরি দেখাবে।</p>
              </div>
                      <Button
                data-testid="button-save-task"
                type="submit"
                className="w-full"
                disabled={createTask.isPending || updateTask.isPending}
              >
                {createTask.isPending || updateTask.isPending ? "সংরক্ষণ হচ্ছে..." : "সংরক্ষণ করুন"}
              </Button>
            </form>
          </DialogContent>
        </Dialog>
      </div>

      {/* Delete Confirmation */}
      <AlertDialog open={!!deleteId} onOpenChange={(o) => !o && setDeleteId(null)}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>টাস্ক মুছবেন?</AlertDialogTitle>
            <AlertDialogDescription>
              এই টাস্ক স্থায়ীভাবে মুছে যাবে। এটি আর ফেরানো যাবে না।
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel>বাতিল</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleDelete}
              className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
              disabled={deleteTask.isPending}
            >
              {deleteTask.isPending ? "মুছছে..." : "হ্যাঁ, মুছুন"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      <Card>
        <CardContent className="p-0">
          {tasksLoading ? (
            <div className="py-12 text-center text-muted-foreground">টাস্ক লোড হচ্ছে...</div>
          ) : tasksError ? (
            <div className="py-12 text-center space-y-3">
              <p className="text-destructive">টাস্ক লোড করা যায়নি।</p>
              <Button variant="outline" size="sm" onClick={() => refetchTasks()}>আবার চেষ্টা করুন</Button>
            </div>
          ) : (!tasks || tasks.length === 0) ? (
            <div className="py-12 text-center text-muted-foreground">
              এখনো কোনো টাস্ক নেই। নতুন টাস্ক তৈরি করুন।
            </div>
          ) : (
            <div className="divide-y">
              {tasks.map((task) => (
                <div
                  key={task.id}
                  data-testid={`task-row-${task.id}`}
                  className="p-4 flex justify-between items-center gap-4"
                >
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-2 flex-wrap">
                      <h4 className="font-semibold truncate">{task.title}</h4>
                      {task.link && <Link className="h-3.5 w-3.5 text-muted-foreground flex-shrink-0" />}
                    </div>
                    <div className="flex gap-2 items-center mt-1 flex-wrap">
                      <Badge variant={task.status === "active" ? "default" : "secondary"}>
                        {task.status === "active" ? "সক্রিয়" : "নিষ্ক্রিয়"}
                      </Badge>
                      <span className="text-sm font-semibold text-primary">৳{task.reward}</span>
                    </div>
                  </div>
                  <div className="flex gap-2 flex-shrink-0">
                      <Button
                      data-testid={`button-edit-task-${task.id}`}
                      variant="outline"
                      size="sm"
                      className="gap-1.5"
                      onClick={() => handleEdit(task)}
                    >
                      <Pencil className="h-3.5 w-3.5" />
                      এডিট
                    </Button>
                    <Button
                      data-testid={`button-delete-task-${task.id}`}
                      variant="destructive"
                      size="sm"
                      className="gap-1.5"
                      onClick={() => setDeleteId(task.id)}
                    >
                      <Trash2 className="h-3.5 w-3.5" />
                      মুছুন
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
}
