import { useState, useEffect } from "react";
import { useGetSettings, useUpdateSettings, getGetSettingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Button } from "@/components/ui/button";
import { useToast } from "@/hooks/use-toast";
import { Settings, Download, Headphones, Palette, TrendingUp } from "lucide-react";

export default function AdminSettings() {
  const queryClient = useQueryClient();
  const { data: settings } = useGetSettings();
  const updateSettings = useUpdateSettings();
  const { toast } = useToast();

  const [commission, setCommission] = useState("");
  const [minWithdrawal, setMinWithdrawal] = useState("");
  const [firstTaskBonus, setFirstTaskBonus] = useState("");
  const [level2Commission, setLevel2Commission] = useState("");
  const [appName, setAppName] = useState("");
  const [primaryColor, setPrimaryColor] = useState("#e11d48");
  const [logoText, setLogoText] = useState("");
  const [appDownloadUrl, setAppDownloadUrl] = useState("");
  const [telegramUrl, setTelegramUrl] = useState("");
  const [whatsappUrl, setWhatsappUrl] = useState("");

  useEffect(() => {
    if (settings) {
      setCommission((settings.referralCommissionPercent ?? 5).toString());
      setMinWithdrawal((settings.minWithdrawal ?? 100).toString());
      setAppName(settings.appName);
      setPrimaryColor(settings.primaryColor);
      setLogoText(settings.logoText);
      setAppDownloadUrl(settings.appDownloadUrl ?? "");
      setTelegramUrl(settings.telegramUrl ?? "");
      setWhatsappUrl(settings.whatsappUrl ?? "");
      setFirstTaskBonus((settings.referralFirstTaskBonus ?? 10).toString());
      setLevel2Commission((settings.level2CommissionPercent ?? 5).toString());
    }
  }, [settings]);

  const save = (data: Parameters<typeof updateSettings.mutate>[0]["data"], successMsg: string) => {
    updateSettings.mutate(
      { data },
      {
        onSuccess: (updated) => {
          queryClient.setQueryData(getGetSettingsQueryKey(), updated);
          toast({ title: successMsg });
        },
        onError: () => toast({ title: "ব্যর্থ হয়েছে", variant: "destructive" }),
      }
    );
  };

  return (
    <div className="space-y-6 max-w-2xl pb-8">
      <div>
        <h1 className="text-2xl font-bold tracking-tight flex items-center gap-2">
          <Settings className="h-6 w-6 text-primary" />
          প্ল্যাটফর্ম সেটিংস
        </h1>
        <p className="text-muted-foreground mt-1 text-sm">অ্যাপের সব কিছু এখান থেকে কন্ট্রোল করুন।</p>
      </div>

      {/* Earning Settings */}
      <Card className="shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-emerald-100 flex items-center justify-center">
              <TrendingUp className="h-4 w-4 text-emerald-600" />
            </div>
            <div>
              <CardTitle className="text-base">আয় সেটিংস</CardTitle>
              <CardDescription className="text-xs">রেফারেল কমিশন ও উইথড্রয়াল লিমিট</CardDescription>
            </div>
          </div>
        </CardHeader>
        <form onSubmit={(e) => { e.preventDefault(); save({ referralCommissionPercent: parseFloat(commission), minWithdrawal: parseFloat(minWithdrawal), referralFirstTaskBonus: parseFloat(firstTaskBonus), level2CommissionPercent: parseFloat(level2Commission) }, "আয় সেটিংস সংরক্ষিত হয়েছে"); }}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">সর্বনিম্ন উইথড্রয়াল (BDT)</Label>
                <Input data-testid="input-min-withdrawal" type="number" min="1" value={minWithdrawal} onChange={(e) => setMinWithdrawal(e.target.value)} required />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">রেফারেল প্রথম টাস্ক বোনাস (BDT)</Label>
                <Input data-testid="input-first-task-bonus" type="number" step="0.5" min="0" value={firstTaskBonus} onChange={(e) => setFirstTaskBonus(e.target.value)} required />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs font-medium flex items-center gap-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-emerald-500 inline-block" />
                  লেভেল ১ কমিশন (%)
                </Label>
                <Input data-testid="input-commission" type="number" step="0.1" min="0" max="100" value={commission} onChange={(e) => setCommission(e.target.value)} required />
                <p className="text-xs text-muted-foreground">সরাসরি রেফারেলের টাস্কে কমিশন।</p>
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs font-medium flex items-center gap-1">
                  <span className="h-2.5 w-2.5 rounded-full bg-violet-500 inline-block" />
                  লেভেল ২ কমিশন (%)
                </Label>
                <Input data-testid="input-level2-commission" type="number" step="0.1" min="0" max="100" value={level2Commission} onChange={(e) => setLevel2Commission(e.target.value)} required />
                <p className="text-xs text-muted-foreground">টিম মেম্বারের রেফারেলের টাস্কে কমিশন।</p>
              </div>
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs font-medium">রেফারেল প্রথম টাস্ক বোনাস (BDT)</Label>
              <Input
                data-testid="input-first-task-bonus"
                type="number"
                step="0.5"
                min="0"
                value={firstTaskBonus}
                onChange={(e) => setFirstTaskBonus(e.target.value)}
                required
              />
              <p className="text-xs text-muted-foreground">রেফার করা ইউজার প্রথম টাস্ক approve হলে রেফারার একবার এই পরিমাণ বোনাস পাবেন।</p>
            </div>
            <Button data-testid="button-save-earning" type="submit" size="sm" disabled={updateSettings.isPending}>
              {updateSettings.isPending ? "সংরক্ষণ হচ্ছে..." : "সংরক্ষণ করুন"}
            </Button>
          </CardContent>
        </form>
      </Card>

      {/* Support Links */}
      <Card className="shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-blue-100 flex items-center justify-center">
              <Headphones className="h-4 w-4 text-blue-600" />
            </div>
            <div>
              <CardTitle className="text-base">সাপোর্ট লিঙ্ক</CardTitle>
              <CardDescription className="text-xs">Telegram ও WhatsApp সাপোর্ট লিঙ্ক সেট করুন</CardDescription>
            </div>
          </div>
        </CardHeader>
        <form onSubmit={(e) => { e.preventDefault(); save({ telegramUrl: telegramUrl.trim() || null, whatsappUrl: whatsappUrl.trim() || null }, "সাপোর্ট লিঙ্ক সংরক্ষিত হয়েছে"); }}>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <span className="h-3.5 w-3.5 rounded-sm bg-[#229ED9] inline-block" />
                Telegram লিঙ্ক
              </Label>
              <Input
                data-testid="input-telegram-url"
                type="url"
                value={telegramUrl}
                onChange={(e) => setTelegramUrl(e.target.value)}
                placeholder="https://t.me/yourusername"
              />
            </div>
            <div className="space-y-1.5">
              <Label className="text-xs flex items-center gap-1.5">
                <span className="h-3.5 w-3.5 rounded-sm bg-[#25D366] inline-block" />
                WhatsApp লিঙ্ক
              </Label>
              <Input
                data-testid="input-whatsapp-url"
                type="url"
                value={whatsappUrl}
                onChange={(e) => setWhatsappUrl(e.target.value)}
                placeholder="https://wa.me/8801XXXXXXXXX"
              />
              <p className="text-xs text-muted-foreground">WhatsApp: https://wa.me/8801XXXXXXXXX (দেশ কোড সহ)</p>
            </div>
            <Button data-testid="button-save-support" type="submit" size="sm" disabled={updateSettings.isPending}>
              {updateSettings.isPending ? "সংরক্ষণ হচ্ছে..." : "লিঙ্ক সংরক্ষণ করুন"}
            </Button>
          </CardContent>
        </form>
      </Card>

      {/* Download App */}
      <Card className="shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-violet-100 flex items-center justify-center">
              <Download className="h-4 w-4 text-violet-600" />
            </div>
            <div>
              <CardTitle className="text-base">অ্যাপ ডাউনলোড লিঙ্ক</CardTitle>
              <CardDescription className="text-xs">ইউজাররা এই লিঙ্ক থেকে APK ডাউনলোড করবেন</CardDescription>
            </div>
          </div>
        </CardHeader>
        <form onSubmit={(e) => { e.preventDefault(); save({ appDownloadUrl: appDownloadUrl.trim() || null }, "ডাউনলোড লিঙ্ক সংরক্ষিত হয়েছে"); }}>
          <CardContent className="space-y-4">
            <div className="space-y-1.5">
              <Label className="text-xs">APK ডাউনলোড URL</Label>
              <Input
                data-testid="input-download-url"
                type="url"
                value={appDownloadUrl}
                onChange={(e) => setAppDownloadUrl(e.target.value)}
                placeholder="https://example.com/app.apk"
              />
              <p className="text-xs text-muted-foreground">Google Drive, Telegram বা সরাসরি APK লিঙ্ক।</p>
            </div>
            <Button data-testid="button-save-download" type="submit" size="sm" disabled={updateSettings.isPending}>
              {updateSettings.isPending ? "সংরক্ষণ হচ্ছে..." : "লিঙ্ক সংরক্ষণ করুন"}
            </Button>
          </CardContent>
        </form>
      </Card>

      {/* Branding */}
      <Card className="shadow-sm">
        <CardHeader className="pb-4">
          <div className="flex items-center gap-2">
            <div className="h-8 w-8 rounded-lg bg-rose-100 flex items-center justify-center">
              <Palette className="h-4 w-4 text-rose-600" />
            </div>
            <div>
              <CardTitle className="text-base">অ্যাপ ব্র্যান্ডিং</CardTitle>
              <CardDescription className="text-xs">নাম, লোগো ও রঙ পরিবর্তন করুন</CardDescription>
            </div>
          </div>
        </CardHeader>
        <form onSubmit={(e) => {
          e.preventDefault();
          if (!logoText.trim()) { toast({ title: "লোগো টেক্সট দিন", variant: "destructive" }); return; }
          save({ appName: appName.trim() || "Earn Space", primaryColor, logoText: logoText.trim().charAt(0).toUpperCase() }, "ব্র্যান্ডিং আপডেট হয়েছে! পেজ রিফ্রেশ করুন।");
        }}>
          <CardContent className="space-y-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="space-y-1.5">
                <Label className="text-xs">অ্যাপের নাম</Label>
                <Input data-testid="input-app-name" value={appName} onChange={(e) => setAppName(e.target.value)} placeholder="Earn Space" required />
              </div>
              <div className="space-y-1.5">
                <Label className="text-xs">লোগো অক্ষর (১টি)</Label>
                <Input data-testid="input-logo-text" value={logoText} onChange={(e) => setLogoText(e.target.value.charAt(0).toUpperCase())} placeholder="E" maxLength={1} required />
              </div>
            </div>

            <div className="space-y-1.5">
              <Label className="text-xs">প্রাইমারি কালার</Label>
              <div className="flex items-center gap-3">
                <input data-testid="input-primary-color" type="color" value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} className="h-10 w-16 cursor-pointer rounded border border-input p-1" />
                <Input value={primaryColor} onChange={(e) => setPrimaryColor(e.target.value)} placeholder="#e11d48" className="font-mono w-32" />
                <div className="h-10 w-10 rounded-full border shadow-sm flex-shrink-0" style={{ backgroundColor: primaryColor }} />
              </div>
            </div>

            {/* Preview */}
            <div className="rounded-xl border bg-gradient-to-br from-muted/30 to-muted/10 p-4">
              <p className="text-xs text-muted-foreground mb-3 font-medium">প্রিভিউ:</p>
              <div className="flex items-center gap-3">
                <div className="flex h-10 w-10 items-center justify-center rounded-full font-bold text-white text-lg shadow" style={{ backgroundColor: primaryColor }}>
                  {logoText || "E"}
                </div>
                <span className="font-bold text-lg" style={{ color: primaryColor }}>{appName || "Earn Space"}</span>
              </div>
            </div>

            <Button data-testid="button-save-branding" type="submit" disabled={updateSettings.isPending} style={{ backgroundColor: primaryColor }} className="text-white" size="sm">
              {updateSettings.isPending ? "সংরক্ষণ হচ্ছে..." : "ব্র্যান্ডিং সংরক্ষণ করুন"}
            </Button>
          </CardContent>
        </form>
      </Card>
    </div>
  );
}
