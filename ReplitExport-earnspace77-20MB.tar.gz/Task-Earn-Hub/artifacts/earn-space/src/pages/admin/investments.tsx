import { useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { useQueryClient } from "@tanstack/react-query";
import { BadgePlus, CircleHelp, Coins, LoaderCircle, RefreshCw, ShieldCheck, ToggleLeft, ToggleRight, Users, XCircle } from "lucide-react";
import {
  getGetMeQueryKey,
  getListBalanceTransactionsQueryKey,
  getListAdminInvestmentPlansQueryKey,
  getListInvestmentPlansQueryKey,
  getListInvestmentsQueryKey,
  useCancelInvestmentPlan,
  useCreateInvestmentPlan,
  useListAdminInvestmentPlans,
  useUpdateInvestmentPlanStatus,
} from "@workspace/api-client-react";
import type { InvestmentPlan, InvestmentPlanInput } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Skeleton } from "@/components/ui/skeleton";
import { Textarea } from "@/components/ui/textarea";
import { useToast } from "@/hooks/use-toast";

const planSchema = z.object({
  title: z.string().min(2, "Enter at least 2 characters").max(120),
  description: z.string().max(1000, "Description is too long"),
  targetAmount: z.coerce.number().positive("Target must be greater than zero"),
  minimumInvestment: z.coerce.number().positive("Minimum contribution must be greater than zero"),
  termDays: z.coerce.number().int().min(1).max(3650),
  ratePercent: z.coerce.number().min(0).max(1000),
  ratePeriodDays: z.coerce.number().int().min(1).max(3650),
}).refine((values) => values.minimumInvestment <= values.targetAmount, {
  path: ["minimumInvestment"],
  message: "Minimum contribution cannot exceed the funding target",
});
type PlanValues = z.infer<typeof planSchema>;
const money = (amount: number) => `৳${Number(amount ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;

export default function AdminInvestments() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const plansQuery = useListAdminInvestmentPlans({ query: { queryKey: getListAdminInvestmentPlansQueryKey(), refetchInterval: 5_000 } });
  const createPlan = useCreateInvestmentPlan();
  const updateStatus = useUpdateInvestmentPlanStatus();
  const cancelPlan = useCancelInvestmentPlan();
  const [planToCancel, setPlanToCancel] = useState<InvestmentPlan | null>(null);
  const currentPlanToCancel = plansQuery.data?.find((plan) => plan.id === planToCancel?.id) ?? planToCancel;
  const form = useForm<PlanValues>({
    resolver: zodResolver(planSchema),
    defaultValues: { title: "", description: "", targetAmount: 10000, minimumInvestment: 500, termDays: 30, ratePercent: 5, ratePeriodDays: 30 },
  });

  const preview = useMemo(() => {
    const amount = Number(form.watch("targetAmount")) || 0;
    const days = Number(form.watch("termDays")) || 0;
    const rate = Number(form.watch("ratePercent")) || 0;
    const period = Number(form.watch("ratePeriodDays")) || 1;
    const profit = Math.round((amount * rate * days / period) * 100) / 100;
    return { profit, total: Math.round((amount + profit) * 100) / 100 };
  }, [form.watch("targetAmount"), form.watch("termDays"), form.watch("ratePercent"), form.watch("ratePeriodDays")]);

  const invalidatePlans = async () => Promise.all([
    queryClient.invalidateQueries({ queryKey: getListAdminInvestmentPlansQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListInvestmentPlansQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getListBalanceTransactionsQueryKey() }),
    queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() }),
  ]);

  const onSubmit = (values: PlanValues) => {
    const payload: InvestmentPlanInput = {
      title: values.title.trim(),
      description: values.description.trim(),
      targetAmount: Number(values.targetAmount),
      minimumInvestment: Number(values.minimumInvestment),
      termDays: Number(values.termDays),
      ratePercent: Number(values.ratePercent),
      ratePeriodDays: Number(values.ratePeriodDays),
    };
    createPlan.mutate({ data: payload }, {
      onSuccess: async () => {
        toast({ title: "Group plan created", description: "Members can now contribute toward the funding target." });
        form.reset({ title: "", description: "", targetAmount: 10000, minimumInvestment: 500, termDays: 30, ratePercent: 5, ratePeriodDays: 30 });
        await invalidatePlans();
      },
      onError: () => toast({ title: "Plan was not created", description: "Review the details and try again.", variant: "destructive" }),
    });
  };

  const togglePlan = (id: number, active: boolean) => updateStatus.mutate({ id, data: { active } }, {
    onSuccess: async () => {
      toast({ title: active ? "Funding reopened" : "Funding paused" });
      await invalidatePlans();
    },
    onError: () => toast({ title: "Plan status was not updated", description: "Please try again.", variant: "destructive" }),
  });

  const confirmCancelPlan = () => {
    if (!planToCancel) return;
    cancelPlan.mutate({ id: planToCancel.id }, {
      onSuccess: async () => {
        toast({ title: "Plan cancelled", description: "All contributions were returned to participants’ main wallets." });
        setPlanToCancel(null);
        await invalidatePlans();
      },
      onError: () => toast({ title: "Plan was not cancelled", description: "It may have reached its target. Refresh the plan list and try again.", variant: "destructive" }),
    });
  };

  const rateLine = (percent: number, periodDays: number) => `${percent}% per ${periodDays} days`;

  return (
    <div className="mx-auto max-w-6xl space-y-7 pb-10" data-testid="page-admin-investments">
      <header className="flex flex-col justify-between gap-4 border-b border-amber-300/10 pb-6 sm:flex-row sm:items-end">
        <div><div className="mb-2 flex items-center gap-2 text-[10px] font-semibold uppercase tracking-[.24em] text-amber-300/70"><ShieldCheck className="h-3.5 w-3.5" /> Administration · Group funding</div><h1 className="text-3xl font-bold tracking-tight text-amber-50">Investment plans</h1><p className="mt-2 max-w-xl text-sm leading-6 text-slate-400">Set a funding target, minimum contribution, term, and simple rate. Every participant starts together when the target is reached.</p></div>
        <div className="rounded-xl border border-amber-200/10 bg-[#0b1830] px-4 py-3"><p className="text-[10px] uppercase tracking-widest text-slate-500">Listed plans</p><p className="mt-1 font-mono text-xl font-semibold text-amber-300" data-testid="text-admin-plan-count">{plansQuery.data?.length ?? 0}</p></div>
      </header>

      <div className="grid items-start gap-6 xl:grid-cols-[minmax(0,1.15fr)_minmax(340px,.85fr)]">
        <section className="space-y-4">
          <div className="flex items-center justify-between"><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-amber-300/70">Plan catalogue</p><h2 className="mt-1 text-xl font-semibold text-amber-50">Published and paused</h2></div><Button variant="outline" size="sm" onClick={() => void plansQuery.refetch()} data-testid="button-refresh-investment-plans"><RefreshCw className="mr-2 h-3.5 w-3.5" />Refresh</Button></div>
          {plansQuery.isLoading ? <div className="space-y-3">{[0, 1, 2].map((item) => <Skeleton key={item} className="h-32 rounded-2xl bg-primary/5" />)}</div> : plansQuery.error ? (
            <div className="rounded-2xl border border-rose-400/20 bg-rose-400/5 p-6 text-center"><p className="font-semibold text-rose-200">Plans could not be loaded</p><p className="mt-1 text-sm text-slate-400">Please retry to see the current catalogue.</p><Button variant="outline" className="mt-4" onClick={() => void plansQuery.refetch()} data-testid="button-retry-admin-plans">Try again</Button></div>
          ) : plansQuery.data?.length ? (
            <div className="space-y-3">
              {plansQuery.data.map((plan) => (
                <article key={plan.id} data-testid={`admin-plan-${plan.id}`} className="rounded-2xl border border-amber-200/10 bg-[#0b1830] p-5 transition-colors hover:border-amber-300/20">
                  <div className="flex flex-wrap items-start justify-between gap-4">
                    <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-amber-50">{plan.title}</h3><Badge className={plan.fundingStatus === "cancelled" ? "border border-slate-300/15 bg-slate-300/[.06] text-slate-400" : plan.fundingStatus === "active" ? "border border-sky-300/20 bg-sky-300/[.08] text-sky-200" : plan.active ? "border border-amber-300/20 bg-amber-300/[.08] text-amber-200" : "border border-slate-300/15 bg-slate-300/[.06] text-slate-400"}>{plan.fundingStatus === "cancelled" ? "Cancelled" : plan.fundingStatus === "active" ? "Term running" : plan.active ? "Funding open" : "Paused"}</Badge><Badge className={plan.active ? "border border-emerald-300/20 bg-emerald-300/[.08] text-emerald-200" : "border border-slate-300/15 bg-slate-300/[.06] text-slate-400"}>{plan.active ? "Published" : "Hidden"}</Badge></div><p className="mt-1 max-w-lg text-sm text-slate-400">{plan.description || "No additional description."}</p></div>
                    <div className="flex flex-wrap items-center gap-2">
                      {plan.fundingStatus === "fundraising" && <Button variant="outline" size="sm" disabled={cancelPlan.isPending} onClick={() => setPlanToCancel(plan)} data-testid={`button-cancel-plan-${plan.id}`}><XCircle className="mr-2 h-4 w-4 text-rose-300" />Cancel & refund</Button>}
                      <Button variant="outline" size="sm" disabled={updateStatus.isPending || plan.fundingStatus !== "fundraising"} onClick={() => togglePlan(plan.id, !plan.active)} data-testid={`button-toggle-plan-${plan.id}`}><span className="mr-2">{plan.active ? <ToggleRight className="h-4 w-4 text-emerald-300" /> : <ToggleLeft className="h-4 w-4 text-slate-400" />}</span>{plan.active ? "Pause funding" : "Resume funding"}</Button>
                    </div>
                  </div>
                  <div className="mt-4 grid grid-cols-2 gap-3 rounded-xl border border-amber-100/[.07] bg-[#081327]/70 p-3 sm:grid-cols-4">
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Funding target</p><p className="mt-1 font-mono text-sm font-semibold text-amber-200">{money(plan.targetAmount)}</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Raised · minimum</p><p className="mt-1 font-mono text-sm font-semibold text-amber-200">{money(plan.totalCollected)} · {money(plan.minimumInvestment)}</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Term</p><p className="mt-1 text-sm font-semibold text-slate-200">{plan.termDays} days</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Simple rate</p><p className="mt-1 text-sm font-semibold text-slate-200">{rateLine(plan.ratePercent, plan.ratePeriodDays)}</p></div>
                  </div>
                  <div className="mt-3 space-y-2">
                    <div className="flex justify-between gap-3 text-xs text-slate-400"><span className="flex items-center gap-1.5"><Users className="h-3.5 w-3.5" />{plan.participantCount} participants</span><span>{plan.fundingStatus === "cancelled" ? "Refunded group" : `${plan.progressPercent.toFixed(1)}% · ${money(plan.remainingAmount)} remaining`}</span></div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-700/60" role="progressbar" aria-label={`${plan.title} funding progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={plan.progressPercent}><div className={`h-full rounded-full ${plan.fundingStatus === "cancelled" ? "bg-slate-500" : "bg-amber-300"}`} style={{ width: `${plan.progressPercent}%` }} /></div>
                    <p className="text-[11px] text-slate-500">{plan.fundingStatus === "active" && plan.activatedAt ? `All participant terms started ${new Date(plan.activatedAt).toLocaleString("en-BD")}` : plan.fundingStatus === "cancelled" ? "All contributions were returned to participants." : `Estimated return at the minimum contribution: ${money(plan.projectedReturn)}`}</p>
                  </div>
                </article>
              ))}
            </div>
          ) : <div className="rounded-2xl border border-dashed border-amber-200/15 bg-[#0b1830]/50 px-6 py-12 text-center"><Coins className="mx-auto h-7 w-7 text-amber-300/60" /><h3 className="mt-3 font-semibold text-amber-50">No plans in the catalogue</h3><p className="mt-1 text-sm text-slate-400">Create a group plan and members can contribute toward its target.</p></div>}
        </section>

        <aside className="space-y-4">
          <Card className="overflow-hidden border-amber-300/15 bg-[#0b1830]">
            <CardHeader className="border-b border-amber-100/[.08] bg-amber-300/[.025]">
              <CardTitle className="flex items-center gap-2 text-lg text-amber-50"><BadgePlus className="h-5 w-5 text-amber-300" />Create a group plan</CardTitle>
              <CardDescription className="text-slate-400">The plan starts raising funds as soon as it is created.</CardDescription>
            </CardHeader>
            <CardContent className="p-5">
              <Form {...form}>
                <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4" data-testid="form-create-investment-plan">
                  <FormField control={form.control} name="title" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Plan title</FormLabel><FormControl><Input {...field} placeholder="e.g. Steady Saver" data-testid="input-plan-title" /></FormControl><FormMessage /></FormItem>} />
                  <FormField control={form.control} name="description" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Description</FormLabel><FormControl><Textarea {...field} rows={3} placeholder="Explain how this plan works for members." className="resize-y" data-testid="input-plan-description" /></FormControl><FormMessage /></FormItem>} />
                  <div className="grid grid-cols-2 gap-3">
                    <FormField control={form.control} name="targetAmount" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Funding target (৳)</FormLabel><FormControl><Input {...field} type="number" min="0.01" step="0.01" data-testid="input-plan-target" /></FormControl><FormMessage /></FormItem>} />
                    <FormField control={form.control} name="minimumInvestment" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Minimum (৳)</FormLabel><FormControl><Input {...field} type="number" min="0.01" step="0.01" data-testid="input-plan-minimum" /></FormControl><FormMessage /></FormItem>} />
                  </div>
                  <p className="text-[0.8rem] text-muted-foreground">Members may contribute any amount at or above the minimum.</p>
                  <div className="grid grid-cols-2 gap-3">
                    <FormField control={form.control} name="termDays" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Term (days)</FormLabel><FormControl><Input {...field} type="number" min="1" max="3650" step="1" data-testid="input-plan-term" /></FormControl><FormMessage /></FormItem>} />
                    <FormField control={form.control} name="ratePercent" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Rate (%)</FormLabel><FormControl><Input {...field} type="number" min="0" max="1000" step="0.01" data-testid="input-plan-rate" /></FormControl><FormMessage /></FormItem>} />
                  </div>
                  <FormField control={form.control} name="ratePeriodDays" render={({ field }) => <FormItem><FormLabel className="text-slate-200">Rate period (days)</FormLabel><FormControl><Input {...field} type="number" min="1" max="3650" step="1" data-testid="input-plan-rate-period" /></FormControl><FormDescription>Profit is simple and proportional, not compounded.</FormDescription><FormMessage /></FormItem>} />
                  <div className="grid grid-cols-2 gap-3 rounded-xl border border-amber-100/10 bg-[#081327] p-3">
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Profit if target funded</p><p className="mt-1 font-mono text-sm font-semibold text-emerald-300">{money(preview.profit)}</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Group maturity return</p><p className="mt-1 font-mono text-sm font-semibold text-amber-200">{money(preview.total)}</p></div>
                  </div>
                  {createPlan.error && <p className="text-sm text-rose-300" role="alert">The plan could not be created. Check each field and retry.</p>}
                  <Button type="submit" className="w-full bg-amber-400 font-semibold text-[#111b2a] hover:bg-amber-300" disabled={createPlan.isPending} data-testid="button-create-investment-plan"><BadgePlus className="mr-2 h-4 w-4" />{createPlan.isPending ? "Creating plan…" : "Create and open funding"}</Button>
                </form>
              </Form>
            </CardContent>
          </Card>
          <div className="flex gap-3 rounded-xl border border-sky-300/10 bg-sky-300/[.035] p-4 text-xs leading-5 text-slate-400"><CircleHelp className="mt-0.5 h-4 w-4 shrink-0 text-sky-300" /><p><span className="font-semibold text-slate-200">Member-facing calculation.</span> Profit = each contribution × rate × term days ÷ rate period days. Terms start together only after the target is reached. Cancelling an unfilled group returns every contribution to its owner.</p></div>
        </aside>
      </div>
      <Dialog open={!!planToCancel} onOpenChange={(open) => !open && !cancelPlan.isPending && setPlanToCancel(null)}>
        <DialogContent className="border-amber-200/15 bg-[#0b1830] text-amber-50 sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Cancel this group plan?</DialogTitle>
            <DialogDescription className="text-slate-400">This will stop fundraising and return every contribution to its owner’s main wallet.</DialogDescription>
          </DialogHeader>
          {currentPlanToCancel && <div className="space-y-3 rounded-xl border border-amber-200/10 bg-[#081327] p-4">
            <div className="flex justify-between gap-3"><span className="text-sm text-slate-400">Plan</span><span className="text-right text-sm font-semibold">{currentPlanToCancel.title}</span></div>
            <div className="flex justify-between gap-3"><span className="text-sm text-slate-400">Raised to date</span><span className="font-mono font-semibold text-amber-200">{money(currentPlanToCancel.totalCollected)}</span></div>
            <div className="flex justify-between gap-3"><span className="text-sm text-slate-400">Participants to refund</span><span className="font-mono font-semibold text-slate-100">{currentPlanToCancel.participantCount}</span></div>
            <p className="text-xs leading-5 text-slate-500">This is available only before the target is reached. Once activated, the group cannot be cancelled here.</p>
          </div>}
          {cancelPlan.error && <p className="text-sm text-rose-300" role="alert">The plan could not be cancelled. Refresh to check its latest status.</p>}
          <DialogFooter>
            <Button variant="outline" onClick={() => setPlanToCancel(null)} disabled={cancelPlan.isPending}>Keep plan open</Button>
            <Button onClick={confirmCancelPlan} disabled={cancelPlan.isPending || currentPlanToCancel?.fundingStatus !== "fundraising"} className="bg-rose-500 font-semibold text-white hover:bg-rose-400" data-testid="button-confirm-cancel-plan"><XCircle className="mr-2 h-4 w-4" />{cancelPlan.isPending ? "Refunding…" : "Cancel and refund"}</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
      {(updateStatus.isPending || cancelPlan.isPending) && <div className="sr-only" aria-live="polite"><LoaderCircle className="h-4 w-4 animate-spin" /> Updating plan status</div>}
    </div>
  );
}