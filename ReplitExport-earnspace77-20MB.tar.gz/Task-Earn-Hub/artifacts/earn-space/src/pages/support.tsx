import { useGetSettings } from "@workspace/api-client-react";
import { MessageCircle, Phone, ArrowRight, Headphones } from "lucide-react";

export default function Support() {
  const { data: settings } = useGetSettings();

  const options = [
    {
      name: "Telegram",
      icon: "/telegram-icon.svg",
      fallbackIcon: MessageCircle,
      color: "from-[#229ED9] to-[#1a7fb5]",
      bg: "bg-[#229ED9]/10",
      border: "border-[#229ED9]/20",
      text: "text-[#229ED9]",
      url: settings?.telegramUrl,
      description: "Telegram-এ আমাদের সাথে যোগাযোগ করুন",
      badge: "দ্রুত সাড়া",
    },
    {
      name: "WhatsApp",
      icon: "/whatsapp-icon.svg",
      fallbackIcon: Phone,
      color: "from-[#25D366] to-[#128C7E]",
      bg: "bg-[#25D366]/10",
      border: "border-[#25D366]/20",
      text: "text-[#25D366]",
      url: settings?.whatsappUrl,
      description: "WhatsApp-এ সরাসরি মেসেজ করুন",
      badge: "২৪/৭ সাপোর্ট",
    },
  ];

  return (
    <div className="max-w-lg mx-auto space-y-6 pb-8">
      {/* Header */}
      <div className="text-center pt-4">
        <div className="inline-flex items-center justify-center h-16 w-16 rounded-2xl bg-gradient-to-br from-primary/20 to-primary/5 border border-primary/20 mb-4 shadow-lg">
          <Headphones className="h-8 w-8 text-primary" />
        </div>
        <h1 className="text-2xl font-bold tracking-tight">সাপোর্ট সেন্টার</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          যেকোনো সমস্যায় আমরা সাহায্য করতে প্রস্তুত
        </p>
      </div>

      {/* Support Cards */}
      <div className="space-y-4">
        {options.map((opt) => {
          const Icon = opt.fallbackIcon;
          return (
            <div key={opt.name}>
              {opt.url ? (
                <a href={opt.url} target="_blank" rel="noreferrer" className="block group">
                  <div className={`relative overflow-hidden rounded-2xl border ${opt.border} shadow-md hover:shadow-xl transition-all duration-300 hover:-translate-y-0.5`} style={{ background: 'hsl(var(--card))' }}>
                    <div className={`absolute inset-0 bg-gradient-to-br ${opt.color} opacity-[0.04] group-hover:opacity-[0.08] transition-opacity`} />
                    <div className="relative flex items-center gap-4 p-5">
                      <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl ${opt.bg} border ${opt.border} shadow-sm`}>
                        <Icon className={`h-7 w-7 ${opt.text}`} />
                      </div>
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-0.5">
                          <h3 className="font-bold text-base">{opt.name}</h3>
                          <span className={`text-[10px] font-semibold px-2 py-0.5 rounded-full ${opt.bg} ${opt.text}`}>
                            {opt.badge}
                          </span>
                        </div>
                        <p className="text-sm text-muted-foreground">{opt.description}</p>
                      </div>
                      <div className={`flex h-9 w-9 flex-shrink-0 items-center justify-center rounded-full bg-gradient-to-br ${opt.color} text-white shadow-md group-hover:scale-110 transition-transform`}>
                        <ArrowRight className="h-4 w-4" />
                      </div>
                    </div>
                  </div>
                </a>
              ) : (
                <div className={`relative overflow-hidden rounded-2xl border border-dashed border-muted-foreground/20 bg-muted/30 p-5 opacity-60`}>
                  <div className="flex items-center gap-4">
                    <div className={`flex h-14 w-14 flex-shrink-0 items-center justify-center rounded-xl bg-muted`}>
                      <Icon className="h-7 w-7 text-muted-foreground" />
                    </div>
                    <div>
                      <h3 className="font-bold text-base">{opt.name}</h3>
                      <p className="text-sm text-muted-foreground">শীঘ্রই চালু হবে</p>
                    </div>
                  </div>
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Info box */}
      <div className="rounded-2xl bg-gradient-to-br from-primary/5 to-primary/10 border border-primary/15 p-5">
        <h4 className="font-semibold text-sm mb-2">সাধারণ জিজ্ঞাসা</h4>
        <div className="space-y-2 text-sm text-muted-foreground">
          <div className="flex gap-2">
            <span className="text-primary font-bold">•</span>
            <span>উইথড্রয়াল সাধারণত ১–৩ কার্যদিবসে প্রক্রিয়া হয়</span>
          </div>
          <div className="flex gap-2">
            <span className="text-primary font-bold">•</span>
            <span>সাবমিশন রিভিউ হতে ২৪ ঘণ্টা লাগতে পারে</span>
          </div>
          <div className="flex gap-2">
            <span className="text-primary font-bold">•</span>
            <span>সমস্যা হলে স্ক্রিনশট সহ যোগাযোগ করুন</span>
          </div>
        </div>
      </div>
    </div>
  );
}
