import { useListTasks, useListSubmissions } from "@workspace/api-client-react";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { CheckSquare, ArrowRight, ExternalLink, Zap, Clock } from "lucide-react";

export default function Tasks() {
  const { data: tasks, isLoading } = useListTasks({ status: "active" });
  const { data: submissions } = useListSubmissions();

  const submittedTaskIds = new Set(submissions?.map((s) => s.taskId) ?? []);

  return (
    <div className="space-y-6 pb-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">সক্রিয় টাস্কসমূহ</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          টাস্ক সম্পন্ন করুন এবং পুরস্কার আয় করুন।
        </p>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      ) : !tasks || tasks.length === 0 ? (
        <div className="rounded-2xl border border-dashed bg-muted/30 py-16 text-center">
          <CheckSquare className="h-12 w-12 text-muted-foreground/30 mx-auto mb-3" />
          <p className="font-medium text-muted-foreground">এখন কোনো সক্রিয় টাস্ক নেই।</p>
          <p className="text-sm text-muted-foreground/70 mt-1">পরে আবার দেখুন।</p>
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {tasks.map((task) => {
            const done = submittedTaskIds.has(task.id);
            return (
              <div
                key={task.id}
                data-testid={`task-card-${task.id}`}
                className={`relative flex flex-col rounded-2xl overflow-hidden transition-all duration-200 ${done ? "opacity-70" : "hover:-translate-y-0.5"}`}
                style={{ background: 'var(--color-card)', border: '1px solid rgba(245,158,11,0.15)', boxShadow: '0 2px 12px rgba(0,0,0,0.25)' }}
              >
                {/* Top accent */}
                <div className="h-1 w-full bg-gradient-to-r from-primary to-primary/50" />

                <div className="flex-1 p-5">
                  {/* Header */}
                  <div className="flex items-start justify-between gap-2 mb-3">
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-base leading-snug line-clamp-2">{task.title}</h3>
                    </div>
                    <div className="flex-shrink-0 flex flex-col items-end gap-1.5">
                      <span className="inline-flex items-center gap-1 rounded-xl bg-primary/10 px-3 py-1 text-sm font-bold text-primary border border-primary/20">
                        <Zap className="h-3.5 w-3.5 fill-primary" />
                        ৳{task.reward}
                      </span>
                      {done && (
                        <span className="text-[10px] font-semibold px-2 py-0.5 rounded-full" style={{ background: 'rgba(52,211,153,0.15)', color: '#34D399', border: '1px solid rgba(52,211,153,0.25)' }}>
                          জমা দেওয়া হয়েছে
                        </span>
                      )}
                    </div>
                  </div>

                  <p className="text-sm text-muted-foreground line-clamp-3 leading-relaxed">
                    {task.description}
                  </p>

                  {task.link && (
                    <div className="mt-3 flex items-center gap-1.5 text-xs text-primary/70">
                      <ExternalLink className="h-3 w-3" />
                      <span className="truncate">লিঙ্ক আছে</span>
                    </div>
                  )}
                </div>

                <div className="px-5 pb-4 pt-2 border-t border-muted/50">
                  <Link href={`/tasks/${task.id}`} className="block">
                    <Button
                      className="w-full gap-2 rounded-xl"
                      variant={done ? "outline" : "default"}
                      size="sm"
                      data-testid={`button-start-task-${task.id}`}
                    >
                      {done ? (
                        <>
                          <Clock className="h-3.5 w-3.5" />
                          বিস্তারিত দেখুন
                        </>
                      ) : (
                        <>
                          টাস্ক শুরু করুন
                          <ArrowRight className="h-3.5 w-3.5" />
                        </>
                      )}
                    </Button>
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
