import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { Link, useLocation } from "wouter";
import { useLogin, getGetMeQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { ArrowRight, LoaderCircle, Lock, Mail } from "lucide-react";
import { AuthShell } from "@/components/auth-shell";

const loginSchema = z.object({
  email: z.string().email("সঠিক ইমেইল লিখুন"),
  password: z.string().min(1, "পাসওয়ার্ড দিন"),
});

type LoginForm = z.infer<typeof loginSchema>;

export default function Login() {
  const [, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const login = useLogin();
  const form = useForm<LoginForm>({
    resolver: zodResolver(loginSchema),
    defaultValues: { email: "", password: "" },
  });

  const onSubmit = (data: LoginForm) => {
    login.mutate(
      { data },
      {
        onSuccess: (user) => {
          queryClient.setQueryData(getGetMeQueryKey(), user);
          setLocation(user.role === "admin" ? "/admin" : "/dashboard");
        },
        onError: () => {
          form.setError("root", { message: "ইমেইল বা পাসওয়ার্ড ভুল। আবার চেষ্টা করুন।" });
        },
      },
    );
  };

  return (
    <AuthShell title="আবার স্বাগতম" description="আপনার অ্যাকাউন্টে প্রবেশ করতে লগইন করুন।">
      <form onSubmit={form.handleSubmit(onSubmit)} className="auth-form" data-testid="form-login">
        <div className="auth-field">
          <label className="auth-label" htmlFor="login-email">ইমেইল</label>
          <div className="auth-input-wrap">
            <Mail className="auth-field-icon h-[17px] w-[17px]" aria-hidden="true" />
            <input
              id="login-email"
              data-testid="input-email"
              type="email"
              autoComplete="email"
              placeholder="name@example.com"
              className="auth-input"
              aria-invalid={!!form.formState.errors.email}
              aria-describedby={form.formState.errors.email ? "login-email-error" : undefined}
              {...form.register("email")}
            />
          </div>
          {form.formState.errors.email && (
            <p className="auth-error" id="login-email-error" role="alert">{form.formState.errors.email.message}</p>
          )}
        </div>

        <div className="auth-field">
          <label className="auth-label" htmlFor="login-password">পাসওয়ার্ড</label>
          <div className="auth-input-wrap">
            <Lock className="auth-field-icon h-[17px] w-[17px]" aria-hidden="true" />
            <input
              id="login-password"
              data-testid="input-password"
              type="password"
              autoComplete="current-password"
              placeholder="••••••••"
              className="auth-input"
              aria-invalid={!!form.formState.errors.password}
              aria-describedby={form.formState.errors.password ? "login-password-error" : undefined}
              {...form.register("password")}
            />
          </div>
          {form.formState.errors.password && (
            <p className="auth-error" id="login-password-error" role="alert">{form.formState.errors.password.message}</p>
          )}
        </div>

        {form.formState.errors.root && (
          <div className="auth-alert" role="alert">{form.formState.errors.root.message}</div>
        )}

        <button data-testid="button-login" type="submit" className="auth-submit" disabled={login.isPending}>
          {login.isPending ? (
            <><LoaderCircle className="h-4 w-4 animate-spin" /> লগইন হচ্ছে...</>
          ) : (
            <>লগইন করুন <ArrowRight className="h-4 w-4" /></>
          )}
        </button>
      </form>

      <p className="auth-switch">
        অ্যাকাউন্ট নেই?{" "}
        <Link href="/register">
          <span className="auth-link cursor-pointer" data-testid="link-register">রেজিস্টার করুন</span>
        </Link>
      </p>
    </AuthShell>
  );
}