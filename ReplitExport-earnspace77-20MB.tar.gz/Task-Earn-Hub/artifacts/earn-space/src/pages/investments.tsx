import { useMemo, useRef, useState } from "react";
import { useQueryClient } from "@tanstack/react-query";
import {
  ArrowDownLeft,
  ArrowUpRight,
  CalendarClock,
  CheckCircle2,
  CircleHelp,
  Clock3,
  Coins,
  HandCoins,
  LockKeyhole,
  RefreshCw,
  ShieldCheck,
  TrendingUp,
  Users,
  Wallet,
} from "lucide-react";
import {
  getGetMeQueryKey,
  getListBalanceTransactionsQueryKey,
  getListInvestmentPlansQueryKey,
  getListInvestmentsQueryKey,
  useCreateInvestment,
  useGetMe,
  useListBalanceTransactions,
  useListInvestmentPlans,
  useListInvestments,
} from "@workspace/api-client-react";
import type { InvestmentPlan } from "@workspace/api-client-react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Skeleton } from "@/components/ui/skeleton";
import { useToast } from "@/hooks/use-toast";

const money = (amount: number) => `৳${Number(amount ?? 0).toLocaleString("en-BD", { minimumFractionDigits: 2, maximumFractionDigits: 2 })}`;
const date = (value: string) => new Date(value).toLocaleDateString("en-BD", { day: "numeric", month: "short", year: "numeric" });
const daysLeft = (value: string) => Math.max(0, Math.ceil((new Date(value).getTime() - Date.now()) / 86_400_000));

function PositionSkeleton() {
  return (
    <div className="grid gap-3 sm:grid-cols-2">
      {[0, 1].map((item) => <Skeleton key={item} className="h-48 rounded-2xl bg-primary/5" />)}
    </div>
  );
}

export default function Investments() {
  const queryClient = useQueryClient();
  const { toast } = useToast();
  const me = useGetMe({ query: { queryKey: getGetMeQueryKey(), refetchInterval: 5_000 } });
  const plansQuery = useListInvestmentPlans({ query: { queryKey: getListInvestmentPlansQueryKey(), refetchInterval: 5_000 } });
  const positionsQuery = useListInvestments({ query: { queryKey: getListInvestmentsQueryKey(), refetchInterval: 5_000 } });
  const transactionsQuery = useListBalanceTransactions(undefined, { query: { queryKey: getListBalanceTransactionsQueryKey(), refetchInterval: 5_000 } });
  const invest = useCreateInvestment();
  const [selectedPlan, setSelectedPlan] = useState<InvestmentPlan | null>(null);
  const [contributionAmount, setContributionAmount] = useState("");
  const investmentRequest = useRef<{ planId: number; amount: string; key: string } | null>(null);
  const currentSelectedPlan = selectedPlan
    ? plansQuery.data?.find((plan) => plan.id === selectedPlan.id) ?? (plansQuery.isSuccess ? null : selectedPlan)
    : null;

  const openPositions = useMemo(() => positionsQuery.data?.filter((position) => position.status === "fundraising" || position.status === "active") ?? [], [positionsQuery.data]);
  const lockedPrincipal = openPositions.reduce((sum, position) => sum + Number(position.principal), 0);
  const projectedPayout = openPositions.reduce((sum, position) => sum + Number(position.totalReturn), 0);
  const history = transactionsQuery.data?.slice().sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()) ?? [];

  const refreshAfterInvest = async () => {
    await Promise.all([
      queryClient.invalidateQueries({ queryKey: getListInvestmentsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListInvestmentPlansQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getListBalanceTransactionsQueryKey() }),
      queryClient.invalidateQueries({ queryKey: getGetMeQueryKey() }),
    ]);
  };

  const confirmInvestment = () => {
    if (!currentSelectedPlan) return;
    const amount = Number(contributionAmount);
    if (!Number.isFinite(amount) || amount < currentSelectedPlan.minimumInvestment || amount > Number(me.data?.balance ?? 0)) return;
    const request = investmentRequest.current?.planId === currentSelectedPlan.id
      && investmentRequest.current.amount === contributionAmount
      ? investmentRequest.current
      : { planId: currentSelectedPlan.id, amount: contributionAmount, key: crypto.randomUUID() };
    investmentRequest.current = request;
    invest.mutate({ data: { planId: currentSelectedPlan.id, amount, idempotencyKey: request.key } }, {
      onSuccess: async () => {
        investmentRequest.current = null;
        toast({ title: "Contribution locked", description: `${currentSelectedPlan.title} is locked. Its term begins when the group reaches its target.` });
        setSelectedPlan(null);
        setContributionAmount("");
        await refreshAfterInvest();
      },
      onError: () => toast({ title: "Contribution was not accepted", description: "The group may have reached its target, or your balance may have changed. Refresh and try again.", variant: "destructive" }),
    });
  };

  const isLoading = me.isLoading || plansQuery.isLoading || positionsQuery.isLoading || transactionsQuery.isLoading;
  const queryError = me.error || plansQuery.error || positionsQuery.error || transactionsQuery.error;
  const retryAll = () => {
    void Promise.all([me.refetch(), plansQuery.refetch(), positionsQuery.refetch(), transactionsQuery.refetch()]);
  };

  return (
    <div className="mx-auto max-w-6xl space-y-8 pb-10" data-testid="page-investments">
      <header className="relative overflow-hidden rounded-[1.6rem] border border-amber-400/20 bg-[radial-gradient(ellipse_at_85%_15%,rgba(245,158,11,.15),transparent_34%),linear-gradient(125deg,#0b1830,#0a1428_68%,#111e32)] p-6 sm:p-8">
        <div className="absolute -right-10 -top-10 h-52 w-52 rounded-full border border-amber-300/10" />
        <div className="absolute -right-2 top-0 h-36 w-36 rounded-full border border-amber-300/10" />
        <div className="relative grid gap-8 md:grid-cols-[1fr_auto] md:items-end">
          <div className="max-w-2xl">
            <div className="mb-4 flex items-center gap-2 text-[11px] font-semibold uppercase tracking-[.24em] text-amber-300/75">
              <span className="h-px w-7 bg-amber-400/70" /> Golden Earn · Investment wallet
            </div>
            <h1 className="max-w-xl text-3xl font-bold tracking-tight text-amber-50 sm:text-4xl">A clear path from saving to maturity.</h1>
            <p className="mt-3 max-w-xl text-sm leading-6 text-slate-300/80">
              Contribute any amount at or above the minimum. Your contribution is locked immediately; everyone’s term starts together when the group reaches its target.
            </p>
          </div>
          <div className="rounded-2xl border border-amber-300/15 bg-[#081327]/70 px-5 py-4 backdrop-blur-sm md:min-w-56">
            <div className="flex items-center gap-2 text-xs text-slate-400"><Wallet className="h-4 w-4 text-amber-300" /> Main wallet available</div>
            <div className="mt-2 font-mono text-2xl font-semibold tracking-tight text-amber-300" data-testid="text-main-wallet">
              {isLoading ? "—" : money(me.data?.balance ?? 0)}
            </div>
            <div className="mt-1 text-[11px] text-slate-500">Available to contribute</div>
          </div>
        </div>
      </header>

      {queryError && (
        <div className="flex flex-col gap-4 rounded-2xl border border-rose-400/20 bg-rose-400/5 p-5 sm:flex-row sm:items-center sm:justify-between" role="alert">
          <div><p className="font-semibold text-rose-200">Investment details could not be loaded</p><p className="mt-1 text-sm text-slate-400">Your balances and positions are unchanged. Try loading them again.</p></div>
          <Button variant="outline" onClick={retryAll} data-testid="button-retry-investments"><RefreshCw className="mr-2 h-4 w-4" />Retry</Button>
        </div>
      )}

      <section aria-label="Investment wallet summary" className="grid gap-3 sm:grid-cols-3">
        {[
          { label: "Locked principal", value: lockedPrincipal, icon: LockKeyhole, color: "text-amber-300", detail: "Raising funds and active terms" },
          { label: "Estimated at maturity", value: projectedPayout, icon: TrendingUp, color: "text-emerald-300", detail: "Principal + estimated profit" },
          { label: "Investment wallet", value: me.data?.investmentBalance ?? 0, icon: Coins, color: "text-sky-300", detail: "Currently held in plans" },
        ].map(({ label, value, icon: Icon, color, detail }) => (
          <Card key={label} className="overflow-hidden border-amber-300/10 bg-[#0b1830] shadow-[0_12px_32px_rgba(0,0,0,.16)]">
            <CardContent className="flex items-start justify-between p-5">
              <div><p className="text-xs font-medium text-slate-400">{label}</p><p className={`mt-2 font-mono text-2xl font-semibold tracking-tight ${color}`} data-testid={`metric-${label.toLowerCase().replaceAll(" ", "-")}`}>{isLoading ? "—" : money(value)}</p><p className="mt-1 text-[11px] text-slate-500">{detail}</p></div>
              <div className="rounded-xl border border-amber-200/10 bg-amber-300/[.06] p-2.5"><Icon className={`h-4 w-4 ${color}`} /></div>
            </CardContent>
          </Card>
        ))}
      </section>

      <section className="space-y-4">
        <div className="flex flex-wrap items-end justify-between gap-3">
          <div><p className="text-[10px] font-semibold uppercase tracking-[.24em] text-amber-300/70">Choose a group plan</p><h2 className="mt-1 text-xl font-semibold text-amber-50">Funding targets</h2></div>
          <p className="flex items-center gap-2 text-xs text-slate-400"><ShieldCheck className="h-4 w-4 text-emerald-300" /> Contributions lock now · term starts at target</p>
        </div>
        {plansQuery.isLoading ? <PositionSkeleton /> : plansQuery.error ? null : plansQuery.data?.length ? (
          <div className="grid gap-4 lg:grid-cols-2">
            {plansQuery.data.filter((plan) => plan.active && plan.fundingStatus !== "cancelled").map((plan) => (
              <Card key={plan.id} data-testid={`card-investment-plan-${plan.id}`} className="group relative overflow-hidden border-amber-300/15 bg-[#0b1830] transition-colors hover:border-amber-300/35">
                <div className="absolute right-0 top-0 h-28 w-28 translate-x-8 -translate-y-8 rounded-full bg-amber-300/[.035] transition-transform group-hover:scale-125" />
                <CardContent className="relative p-5 sm:p-6">
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div><Badge className={`border text-[10px] font-medium ${plan.fundingStatus === "fundraising" ? "border-amber-300/20 bg-amber-300/[.08] text-amber-200 hover:bg-amber-300/[.08]" : "border-emerald-300/20 bg-emerald-300/[.08] text-emerald-200 hover:bg-emerald-300/[.08]"}`}>{plan.fundingStatus === "fundraising" ? "Raising funds" : "Target reached"}</Badge><h3 className="mt-3 text-lg font-semibold text-amber-50">{plan.title}</h3><p className="mt-1 max-w-lg text-sm leading-5 text-slate-400">{plan.description}</p></div>
                    <div className="text-right"><p className="text-[10px] uppercase tracking-widest text-slate-500">Funding target</p><p className="mt-1 font-mono text-xl font-semibold text-amber-300">{money(plan.targetAmount)}</p></div>
                  </div>
                  <div className="my-5 grid grid-cols-3 divide-x divide-amber-100/10 rounded-xl border border-amber-100/10 bg-[#081327]/70 py-3">
                    <div className="px-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Minimum</p><p className="mt-1 text-sm font-semibold text-slate-100">{money(plan.minimumInvestment)}</p></div>
                    <div className="px-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Term</p><p className="mt-1 text-sm font-semibold text-slate-100">{plan.termDays} days</p></div>
                    <div className="px-3"><p className="text-[10px] uppercase tracking-wider text-slate-500">Rate</p><p className="mt-1 text-sm font-semibold text-slate-100">{plan.ratePercent}% / {plan.ratePeriodDays}d</p></div>
                  </div>
                  <div className="mb-5 space-y-2">
                    <div className="flex items-center justify-between gap-3 text-xs"><span className="flex items-center gap-2 text-slate-400"><Users className="h-3.5 w-3.5" />{money(plan.totalCollected)} raised · {plan.participantCount} {plan.participantCount === 1 ? "participant" : "participants"}</span><span className="font-medium text-amber-200">{plan.progressPercent.toFixed(1)}%</span></div>
                    <div className="h-2 overflow-hidden rounded-full bg-slate-700/60" role="progressbar" aria-label={`${plan.title} funding progress`} aria-valuemin={0} aria-valuemax={100} aria-valuenow={plan.progressPercent}><div className="h-full rounded-full bg-gradient-to-r from-amber-500 to-yellow-300 transition-[width]" style={{ width: `${plan.progressPercent}%` }} /></div>
                    <p className="text-[11px] text-slate-500">{plan.fundingStatus === "fundraising" ? `${money(plan.remainingAmount)} remaining to activate` : `Activated ${plan.activatedAt ? date(plan.activatedAt) : "now"} · term is running`}</p>
                  </div>
                  <div className="flex flex-col gap-3 sm:flex-row sm:items-center sm:justify-between">
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Return at minimum contribution</p><p className="font-mono text-lg font-semibold text-amber-100" data-testid={`text-plan-return-${plan.id}`}>{money(plan.projectedReturn)} <span className="text-xs font-medium text-amber-300/70">· {Number(plan.projectedReturnPercent).toFixed(2)}% total</span></p></div>
                    <Button className="bg-amber-400 font-semibold text-[#111b2a] hover:bg-amber-300" disabled={plan.fundingStatus !== "fundraising"} onClick={() => { setContributionAmount(String(plan.minimumInvestment)); setSelectedPlan(plan); }} data-testid={`button-invest-plan-${plan.id}`}>
                      <HandCoins className="mr-2 h-4 w-4" /> {plan.fundingStatus === "fundraising" ? "Contribute" : "Term started"}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-amber-200/15 bg-[#0b1830]/60 px-6 py-12 text-center">
            <CircleHelp className="mx-auto h-7 w-7 text-amber-300/60" /><h3 className="mt-3 font-semibold text-amber-50">No plans are available right now</h3><p className="mt-1 text-sm text-slate-400">Check back later for plans published by Golden Earn.</p>
          </div>
        )}
      </section>

      <section className="space-y-4">
        <div className="flex items-end justify-between gap-3"><div><p className="text-[10px] font-semibold uppercase tracking-[.24em] text-amber-300/70">Your funds, accounted for</p><h2 className="mt-1 text-xl font-semibold text-amber-50">Contribution history</h2></div><span className="text-xs text-slate-500">{openPositions.length} open</span></div>
        {positionsQuery.isLoading ? <PositionSkeleton /> : positionsQuery.error ? null : positionsQuery.data?.length ? (
          <div className="grid gap-3">
            {positionsQuery.data.map((position) => {
              const raising = position.status === "fundraising";
              const active = position.status === "active";
              const refunded = position.status === "refunded";
              const open = raising || active;
              const statusLabel = raising ? "Locked · raising funds" : active ? "Term running" : refunded ? "Refunded" : "Matured";
              const badgeClass = raising
                ? "border border-amber-300/15 bg-amber-300/[.08] text-amber-200"
                : active
                  ? "border border-sky-300/15 bg-sky-300/[.08] text-sky-200"
                  : refunded
                    ? "border border-slate-300/15 bg-slate-300/[.06] text-slate-300"
                    : "border border-emerald-300/15 bg-emerald-300/[.08] text-emerald-200";
              return (
                <article key={position.id} data-testid={`position-${position.id}`} className="grid gap-4 rounded-2xl border border-amber-200/10 bg-[#0b1830] p-5 sm:grid-cols-[1fr_auto] sm:items-center">
                  <div className="flex gap-4">
                    <div className={`mt-0.5 flex h-10 w-10 shrink-0 items-center justify-center rounded-xl border ${open ? "border-amber-300/15 bg-amber-300/[.08]" : "border-emerald-300/15 bg-emerald-300/[.08]"}`}>
                      {open ? <Clock3 className="h-5 w-5 text-amber-300" /> : <CheckCircle2 className="h-5 w-5 text-emerald-300" />}
                    </div>
                    <div className="min-w-0"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold text-amber-50">{position.planTitle}</h3><Badge className={badgeClass}>{statusLabel}</Badge></div>
                      <div className="mt-2 flex flex-wrap gap-x-4 gap-y-1 text-xs text-slate-400"><span>Contributed {date(position.investedAt)}</span>{position.activationAt && <span>Term started {date(position.activationAt)}</span>}{position.maturityAt && <span>Matures {date(position.maturityAt)}</span>}{position.maturityAt && active && <span>{daysLeft(position.maturityAt)} days remaining</span>}{position.settledAt && <span>Settled {date(position.settledAt)}</span>}{position.refundedAt && <span>Refunded {date(position.refundedAt)}</span>}</div>
                      <div className="mt-3 max-w-md">
                        <div className="flex items-center justify-between gap-3 text-[11px] text-slate-400"><span>{money(position.totalCollected)} raised · {position.participantCount} participants</span><span>{position.fundingStatus === "cancelled" ? "Group cancelled" : `${position.progressPercent.toFixed(1)}%`}</span></div>
                        <div className="mt-1.5 h-1.5 overflow-hidden rounded-full bg-slate-700/60"><div className={`h-full rounded-full ${position.fundingStatus === "cancelled" ? "bg-slate-500" : "bg-amber-300"}`} style={{ width: `${position.progressPercent}%` }} /></div>
                      </div>
                    </div>
                  </div>
                  <div className="grid grid-cols-3 gap-4 border-t border-amber-100/10 pt-3 sm:border-0 sm:pt-0 sm:text-right">
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">Contribution</p><p className="mt-1 font-mono text-sm font-semibold text-slate-100">{money(position.principal)}</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">{refunded ? "Profit" : "Est. profit"}</p><p className="mt-1 font-mono text-sm font-semibold text-emerald-300">{refunded ? "—" : `+${money(position.estimatedProfit)}`}</p></div>
                    <div><p className="text-[10px] uppercase tracking-wider text-slate-500">{refunded ? "Returned" : open ? "At maturity" : "Total return"}</p><p className="mt-1 font-mono text-sm font-semibold text-amber-300">{money(refunded ? position.principal : position.totalReturn)}</p></div>
                  </div>
                </article>
              );
            })}
          </div>
        ) : (
          <div className="rounded-2xl border border-dashed border-amber-200/15 bg-[#0b1830]/60 px-6 py-10 text-center">
            <LockKeyhole className="mx-auto h-7 w-7 text-amber-300/60" /><h3 className="mt-3 font-semibold text-amber-50">Your investment wallet is ready</h3><p className="mt-1 text-sm text-slate-400">Your locked contributions, group progress, and maturity dates will appear here.</p>
          </div>
        )}
      </section>

      <section className="overflow-hidden rounded-2xl border border-amber-200/10 bg-[#0b1830]">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-amber-100/10 px-5 py-4"><div><p className="text-[10px] font-semibold uppercase tracking-[.2em] text-amber-300/70">Wallet activity</p><h2 className="mt-1 font-semibold text-amber-50">Transaction history</h2></div><span className="text-xs text-slate-500">{history.length} entries</span></div>
        {transactionsQuery.isLoading ? <div className="space-y-3 p-5"><Skeleton className="h-10" /><Skeleton className="h-10" /><Skeleton className="h-10" /></div> : transactionsQuery.error ? <div className="p-8 text-center text-sm text-slate-400">Transaction history could not be loaded.</div> : history.length ? (
          <div className="divide-y divide-amber-100/[.07]">
            {history.map((transaction) => {
              const incoming = transaction.amount >= 0;
              return <div key={transaction.id} data-testid={`transaction-${transaction.id}`} className="grid gap-3 px-5 py-4 sm:grid-cols-[1fr_auto] sm:items-center">
                <div className="flex min-w-0 items-center gap-3"><div className={`flex h-9 w-9 shrink-0 items-center justify-center rounded-lg ${incoming ? "bg-emerald-300/[.08] text-emerald-300" : "bg-amber-300/[.08] text-amber-300"}`}>{incoming ? <ArrowDownLeft className="h-4 w-4" /> : <ArrowUpRight className="h-4 w-4" />}</div><div className="min-w-0"><p className="truncate text-sm font-medium text-slate-100">{transaction.description}</p><p className="mt-0.5 text-xs text-slate-500">{date(transaction.createdAt)} · {transaction.wallet === "investment" ? "Investment wallet" : "Main wallet"}</p></div></div>
                <div className="text-right"><p className={`font-mono text-sm font-semibold ${incoming ? "text-emerald-300" : "text-slate-200"}`}>{incoming ? "+" : "−"}{money(Math.abs(transaction.amount))}</p><p className="text-[10px] text-slate-500">Balance {money(transaction.balanceAfter)}</p></div>
              </div>;
            })}
          </div>
        ) : <div className="px-6 py-10 text-center"><CalendarClock className="mx-auto h-6 w-6 text-slate-500" /><p className="mt-2 text-sm text-slate-400">No wallet activity yet.</p></div>}
      </section>

      <div className="flex items-start gap-3 rounded-xl border border-sky-300/10 bg-sky-300/[.035] p-4 text-xs leading-5 text-slate-400">
        <CircleHelp className="mt-0.5 h-4 w-4 shrink-0 text-sky-300" /><p><span className="font-semibold text-slate-200">How returns work.</span> Contributions are locked immediately. The group’s term starts only after its target is reached, and each participant’s term and maturity date start together. Profit is simple, not compounded; principal and estimated profit are returned to your main wallet at maturity.</p>
      </div>

      <Dialog open={!!selectedPlan} onOpenChange={(open) => !open && !invest.isPending && setSelectedPlan(null)}>
        <DialogContent className="border-amber-200/15 bg-[#0b1830] text-amber-50 sm:max-w-md">
          <DialogHeader><DialogTitle className="text-xl">Review your contribution</DialogTitle><DialogDescription className="text-slate-400">Your contribution moves from your main wallet and locks now. The plan’s term starts when the funding target is reached.</DialogDescription></DialogHeader>
          {currentSelectedPlan && <div className="space-y-4 rounded-xl border border-amber-200/10 bg-[#081327] p-4">
            <div className="flex justify-between gap-4"><span className="text-sm text-slate-400">Plan</span><span className="text-right text-sm font-semibold">{currentSelectedPlan.title}</span></div>
            <label className="block space-y-2"><span className="text-sm text-slate-400">Contribution amount (৳)</span><input value={contributionAmount} onChange={(event) => setContributionAmount(event.target.value)} type="number" min={currentSelectedPlan.minimumInvestment} max={me.data?.balance ?? undefined} step="0.01" inputMode="decimal" className="w-full rounded-md border border-amber-200/15 bg-[#0b1830] px-3 py-2 font-mono text-amber-50 outline-none focus:border-amber-300" aria-label="Contribution amount" data-testid="input-contribution-amount" /></label>
            <div className="flex justify-between gap-4 text-xs"><span className="text-slate-400">Minimum</span><span className="font-mono text-slate-200">{money(currentSelectedPlan.minimumInvestment)}</span></div>
            <div className="flex justify-between gap-4 text-xs"><span className="text-slate-400">Still needed for target</span><span className="font-mono text-slate-200">{money(currentSelectedPlan.remainingAmount)}</span></div>
            {Number(contributionAmount) >= currentSelectedPlan.minimumInvestment && <div className="space-y-2 border-t border-amber-100/10 pt-3">
              <div className="flex justify-between gap-4"><span className="text-sm text-slate-400">Estimated profit after activation</span><span className="font-mono font-semibold text-emerald-300">+{money(Number(contributionAmount) * currentSelectedPlan.ratePercent * currentSelectedPlan.termDays / (100 * currentSelectedPlan.ratePeriodDays))}</span></div>
              <div className="flex justify-between gap-4"><span className="text-sm font-medium text-slate-300">Estimated maturity return</span><span className="font-mono font-semibold text-amber-200">{money(Number(contributionAmount) + Number(contributionAmount) * currentSelectedPlan.ratePercent * currentSelectedPlan.termDays / (100 * currentSelectedPlan.ratePeriodDays))}</span></div>
            </div>}
            <p className="text-xs leading-5 text-slate-500">The term is {currentSelectedPlan.termDays} days from group activation. You can track progress here; contributions cannot be withdrawn while the group is raising funds or the term is running.</p>
          </div>}
          {!currentSelectedPlan && <p className="text-sm text-rose-300" role="alert">This plan is no longer accepting contributions. Close this dialog and choose an open plan.</p>}
          {invest.error && <p className="text-sm text-rose-300" role="alert">The investment could not be created. Please try again.</p>}
          <DialogFooter><Button variant="outline" onClick={() => setSelectedPlan(null)} disabled={invest.isPending} data-testid="button-cancel-investment">Go back</Button><Button onClick={confirmInvestment} disabled={invest.isPending || !currentSelectedPlan || currentSelectedPlan.fundingStatus !== "fundraising" || Number(contributionAmount) < currentSelectedPlan.minimumInvestment || Number(contributionAmount) > Number(me.data?.balance ?? 0)} className="bg-amber-400 font-semibold text-[#111b2a] hover:bg-amber-300" data-testid="button-confirm-investment"><LockKeyhole className="mr-2 h-4 w-4" />{invest.isPending ? "Locking…" : "Confirm contribution"}</Button></DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}