import { useGetMe, useListReferrals, useGetSettings } from "@workspace/api-client-react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { useToast } from "@/hooks/use-toast";
import { Copy, Users, Gift, Star, TrendingUp, ChevronRight, UserCheck, Network } from "lucide-react";

export default function Referral() {
  const { data: user } = useGetMe();
  const { data: team } = useListReferrals();
  const { data: settings } = useGetSettings();
  const { toast } = useToast();

  const referralLink = user
    ? `${window.location.origin}/register?ref=${user.referralCode}`
    : "";

  const copyLink = () => {
    if (!referralLink) return;
    navigator.clipboard.writeText(referralLink).then(() => {
      toast({ title: "কপি হয়েছে!", description: "রেফারেল লিংক কপি হয়েছে।" });
    }).catch(() => {
      toast({ title: "কপি ব্যর্থ", variant: "destructive" });
    });
  };

  const copyCode = () => {
    if (!user?.referralCode) return;
    navigator.clipboard.writeText(user.referralCode).then(() => {
      toast({ title: "কোড কপি হয়েছে!" });
    });
  };

  const level1Count = team?.direct?.length ?? 0;
  const level2Count = team?.indirect?.length ?? 0;
  const totalTeam = level1Count + level2Count;
  const l1Pct = settings?.referralCommissionPercent ?? 5;
  const l2Pct = settings?.level2CommissionPercent ?? 5;

  return (
    <div className="space-y-6 pb-4">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold tracking-tight">রেফার করুন ও আয় করুন</h1>
        <p className="text-muted-foreground mt-1 text-sm">
          ২-স্তর রেফারেল সিস্টেম — টিম বড় করুন, আয় বাড়ান।
        </p>
      </div>

      {/* Commission Info Cards */}
      <div className="grid grid-cols-3 gap-3">
        <div className="rounded-2xl bg-gradient-to-br from-primary/10 to-primary/5 border border-primary/20 p-4 text-center">
          <div className="text-2xl font-extrabold text-primary">{totalTeam}</div>
          <div className="text-xs text-muted-foreground mt-0.5 font-medium">মোট টিম</div>
        </div>
        <div className="rounded-2xl p-4 text-center" style={{ background: 'rgba(52,211,153,0.08)', border: '1px solid rgba(52,211,153,0.25)' }}>
          <div className="text-2xl font-extrabold" style={{ color: '#34D399' }}>{l1Pct}%</div>
          <div className="text-xs text-muted-foreground mt-0.5 font-medium">লেভেল ১</div>
        </div>
        <div className="rounded-2xl p-4 text-center" style={{ background: 'rgba(167,139,250,0.08)', border: '1px solid rgba(167,139,250,0.25)' }}>
          <div className="text-2xl font-extrabold" style={{ color: '#A78BFA' }}>{l2Pct}%</div>
          <div className="text-xs text-muted-foreground mt-0.5 font-medium">লেভেল ২</div>
        </div>
      </div>

      {/* How it works */}
      <Card className="border-none shadow-sm bg-gradient-to-br from-primary/5 via-primary/3 to-transparent">
        <CardHeader className="pb-3">
          <CardTitle className="text-sm flex items-center gap-2">
            <Network className="h-4 w-4 text-primary" />
            কীভাবে কাজ করে?
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex items-start gap-3">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-emerald-500 text-white text-xs font-bold">১</div>
            <div>
              <p className="text-sm font-semibold">লেভেল ১ — সরাসরি রেফারেল</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                আপনি যাকে রেফার করবেন — তার প্রতিটি অনুমোদিত টাস্কে আপনি <span className="font-semibold text-emerald-600">{l1Pct}%</span> কমিশন পাবেন।
              </p>
            </div>
          </div>
          <div className="ml-3.5 border-l-2 border-dashed border-muted-foreground/20 h-4" />
          <div className="flex items-start gap-3">
            <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-violet-500 text-white text-xs font-bold">২</div>
            <div>
              <p className="text-sm font-semibold">লেভেল ২ — টিম রেফারেল</p>
              <p className="text-xs text-muted-foreground mt-0.5">
                আপনার রেফার করা ব্যক্তি যাকে রেফার করবে — তার টাস্কেও আপনি <span className="font-semibold text-violet-600">{l2Pct}%</span> কমিশন পাবেন!
              </p>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Referral Link */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3">
          <CardTitle className="flex items-center gap-2 text-base">
            <Gift className="h-5 w-5 text-primary" />
            আপনার রেফারেল লিংক
          </CardTitle>
          <CardDescription className="text-xs">এই লিংক শেয়ার করুন বন্ধুদের সাথে</CardDescription>
        </CardHeader>
        <CardContent className="space-y-3">
          <div className="flex gap-2">
            <Input
              data-testid="input-referral-link"
              value={referralLink}
              readOnly
              className="text-xs font-mono bg-muted"
            />
            <Button
              data-testid="button-copy-link"
              onClick={copyLink}
              variant="outline"
              size="sm"
              className="gap-1.5 flex-shrink-0"
            >
              <Copy className="h-3.5 w-3.5" />
              কপি
            </Button>
          </div>

          <div className="rounded-xl border bg-muted/30 p-3 flex items-center justify-between">
            <div>
              <p className="text-xs text-muted-foreground mb-0.5">আপনার কোড</p>
              <span
                data-testid="text-referral-code"
                className="text-xl font-extrabold tracking-widest text-primary"
              >
                {user?.referralCode}
              </span>
            </div>
            <Button
              data-testid="button-copy-code"
              variant="ghost"
              size="sm"
              onClick={copyCode}
              className="h-8 w-8 p-0"
            >
              <Copy className="h-4 w-4" />
            </Button>
          </div>
        </CardContent>
      </Card>

      {/* Team — Level 1 */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-7 w-7 rounded-full bg-emerald-500 flex items-center justify-center text-white text-xs font-bold">১</div>
              <div>
                <CardTitle className="text-sm">সরাসরি রেফারেল</CardTitle>
                <CardDescription className="text-xs">আপনি সরাসরি যাদের এনেছেন</CardDescription>
              </div>
            </div>
            <Badge className="bg-emerald-100 text-emerald-700 border-0 text-xs">
              {level1Count} জন
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {level1Count === 0 ? (
            <div className="py-6 text-center">
              <UserCheck className="h-9 w-9 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">এখনো কেউ যোগ দেননি।</p>
              <p className="text-xs text-muted-foreground mt-0.5">লিংক শেয়ার করুন!</p>
            </div>
          ) : (
            <div className="space-y-2">
              {team!.direct.map((ref) => (
                <div
                  key={ref.id}
                  data-testid={`referral-row-${ref.id}`}
                  className="flex items-center justify-between rounded-xl bg-emerald-50/60 border border-emerald-100 px-3 py-2.5"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-full bg-emerald-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {ref.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-semibold text-sm leading-tight">{ref.name}</p>
                      <p className="text-xs text-muted-foreground">{ref.email}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <Badge variant="outline" className="text-xs border-emerald-200 text-emerald-700 bg-white">
                      {new Date(ref.createdAt).toLocaleDateString("bn-BD")}
                    </Badge>
                  </div>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Team — Level 2 */}
      <Card className="shadow-sm">
        <CardHeader className="pb-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <div className="h-7 w-7 rounded-full bg-violet-500 flex items-center justify-center text-white text-xs font-bold">২</div>
              <div>
                <CardTitle className="text-sm">টিম রেফারেল</CardTitle>
                <CardDescription className="text-xs">আপনার টিম মেম্বারদের রেফারেল</CardDescription>
              </div>
            </div>
            <Badge className="bg-violet-100 text-violet-700 border-0 text-xs">
              {level2Count} জন
            </Badge>
          </div>
        </CardHeader>
        <CardContent>
          {level2Count === 0 ? (
            <div className="py-6 text-center">
              <Network className="h-9 w-9 text-muted-foreground/30 mx-auto mb-2" />
              <p className="text-sm text-muted-foreground">আপনার টিম এখনো কাউকে রেফার করেনি।</p>
              <p className="text-xs text-muted-foreground mt-0.5">আপনার লেভেল-১ টিম বড় হলে এটি বাড়বে।</p>
            </div>
          ) : (
            <div className="space-y-2">
              {team!.indirect.map((ref) => (
                <div
                  key={ref.id}
                  className="flex items-center justify-between rounded-xl bg-violet-50/60 border border-violet-100 px-3 py-2.5"
                >
                  <div className="flex items-center gap-2.5">
                    <div className="h-8 w-8 rounded-full bg-violet-500 flex items-center justify-center text-white text-xs font-bold shrink-0">
                      {ref.name.charAt(0).toUpperCase()}
                    </div>
                    <div>
                      <p className="font-semibold text-sm leading-tight">{ref.name}</p>
                      {ref.referredByName && (
                        <p className="text-xs text-muted-foreground flex items-center gap-1 mt-0.5">
                          <ChevronRight className="h-3 w-3" />
                          {ref.referredByName} এর রেফারেল
                        </p>
                      )}
                    </div>
                  </div>
                  <Badge variant="outline" className="text-xs border-violet-200 text-violet-700 bg-white">
                    {new Date(ref.createdAt).toLocaleDateString("bn-BD")}
                  </Badge>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>

      {/* Earnings summary */}
      {totalTeam > 0 && (
        <Card className="shadow-sm border-primary/20 bg-gradient-to-br from-primary/5 to-transparent">
          <CardContent className="pt-4 pb-4">
            <div className="flex items-center gap-3">
              <div className="h-10 w-10 rounded-xl bg-primary/10 flex items-center justify-center shrink-0">
                <TrendingUp className="h-5 w-5 text-primary" />
              </div>
              <div>
                <p className="font-semibold text-sm">আপনার টিম সক্রিয় আছে!</p>
                <p className="text-xs text-muted-foreground mt-0.5">
                  {level1Count} জন সরাসরি ({l1Pct}% কমিশন) + {level2Count} জন টিম ({l2Pct}% কমিশন)।
                  তাদের প্রতিটি অনুমোদিত টাস্কে আপনি কমিশন পাবেন।
                </p>
              </div>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
