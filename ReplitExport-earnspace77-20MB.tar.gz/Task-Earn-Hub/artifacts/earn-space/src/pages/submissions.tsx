import { useListSubmissions } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Link } from "wouter";
import { ClipboardList, ExternalLink } from "lucide-react";

export default function Submissions() {
  const { data: submissions, isLoading } = useListSubmissions();

  const statusLabel = (s: string) =>
    s === "approved" ? "অনুমোদিত" : s === "rejected" ? "প্রত্যাখ্যাত" : "অপেক্ষমান";

  const statusVariant = (s: string): "default" | "secondary" | "destructive" =>
    s === "approved" ? "default" : s === "rejected" ? "destructive" : "secondary";

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold tracking-tight">আমার কাজের ইতিহাস</h1>
        <p className="text-muted-foreground mt-1">আপনার জমা দেওয়া কাজের স্ট্যাটাস ট্র্যাক করুন।</p>
      </div>

      {isLoading ? (
        <div className="flex items-center justify-center h-48">
          <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent" />
        </div>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>সাবমিশন ইতিহাস</CardTitle>
          </CardHeader>
          <CardContent>
            {!submissions || submissions.length === 0 ? (
              <div className="py-12 text-center">
                <ClipboardList className="h-10 w-10 text-muted-foreground/40 mx-auto mb-3" />
                <p className="text-sm text-muted-foreground">এখনো কোনো কাজ জমা দেননি।</p>
                <Button asChild variant="link" className="mt-2">
                  <Link href="/tasks">টাস্ক খুঁজুন</Link>
                </Button>
              </div>
            ) : (
              <div className="divide-y">
                {submissions.map((sub) => (
                  <div
                    key={sub.id}
                    data-testid={`submission-row-${sub.id}`}
                    className="py-4 first:pt-0 last:pb-0 flex flex-col sm:flex-row sm:items-start justify-between gap-4"
                  >
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap">
                        <h4 className="font-semibold">
                          {sub.task?.title || `টাস্ক #${sub.taskId}`}
                        </h4>
                        {sub.task?.reward && (
                          <span className="text-sm font-semibold text-primary">
                            ৳{sub.task.reward}
                          </span>
                        )}
                      </div>
                      <p className="text-sm text-muted-foreground mt-1">
                        জমা দেওয়া: {new Date(sub.createdAt).toLocaleDateString("bn-BD")}
                      </p>
                      <p className="text-sm text-muted-foreground mt-0.5 line-clamp-2">
                        {sub.description}
                      </p>
                      {sub.status === "rejected" && sub.rejectionReason && (
                        <p className="text-sm text-destructive mt-1 font-medium">
                          কারণ: {sub.rejectionReason}
                        </p>
                      )}
                    </div>
                    <div className="flex items-center gap-3 flex-shrink-0">
                      {sub.screenshotUrl && (
                        <a
                          data-testid={`link-screenshot-${sub.id}`}
                          href={sub.screenshotUrl}
                          target="_blank"
                          rel="noreferrer"
                          className="flex items-center gap-1 text-xs text-primary hover:underline"
                        >
                          <ExternalLink className="h-3.5 w-3.5" />
                          প্রমাণ
                        </a>
                      )}
                      <Badge variant={statusVariant(sub.status)}>
                        {statusLabel(sub.status)}
                      </Badge>
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  );
}
