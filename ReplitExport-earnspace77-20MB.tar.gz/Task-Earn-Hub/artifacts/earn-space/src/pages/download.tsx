import { useGetSettings } from "@workspace/api-client-react";
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Download, Smartphone, AlertCircle } from "lucide-react";

export default function DownloadApp() {
  const { data: settings, isLoading } = useGetSettings();

  const downloadUrl = settings?.appDownloadUrl;

  return (
    <div className="max-w-md mx-auto space-y-6">
      <div>
        <h1 className="text-2xl font-bold tracking-tight">অ্যাপ ডাউনলোড</h1>
        <p className="text-muted-foreground mt-1">আমাদের অ্যাপ ইনস্টল করুন এবং সহজেই আয় করুন।</p>
      </div>

      <Card className="overflow-hidden">
        <div className="h-2 bg-primary" />
        <CardHeader className="text-center pt-8">
          <div className="mx-auto mb-4 flex h-20 w-20 items-center justify-center rounded-2xl bg-primary/10 text-primary shadow-sm">
            <Smartphone className="h-10 w-10" />
          </div>
          <CardTitle className="text-xl">{settings?.appName ?? "Earn Space"} অ্যাপ</CardTitle>
          <CardDescription>
            আমাদের অ্যাপ ডাউনলোড করে আরো সহজে টাস্ক করুন, আয় করুন এবং উইথড্রয়াল করুন।
          </CardDescription>
        </CardHeader>
        <CardContent className="pb-8 space-y-4">
          {isLoading ? (
            <div className="flex items-center justify-center py-4">
              <div className="h-6 w-6 animate-spin rounded-full border-2 border-primary border-t-transparent" />
            </div>
          ) : downloadUrl ? (
            <>
              <a href={downloadUrl} target="_blank" rel="noreferrer" className="block">
                <Button className="w-full h-12 text-base gap-2" size="lg">
                  <Download className="h-5 w-5" />
                  ডাউনলোড করুন
                </Button>
              </a>
              <p className="text-center text-xs text-muted-foreground">
                APK ফাইল — Android ফোনের জন্য
              </p>
            </>
          ) : (
            <div className="flex flex-col items-center gap-3 py-4 text-center">
              <AlertCircle className="h-8 w-8 text-muted-foreground/50" />
              <p className="text-sm text-muted-foreground">
                ডাউনলোড লিঙ্ক এখনো সেট করা হয়নি।<br />
                শীঘ্রই আসছে!
              </p>
            </div>
          )}
        </CardContent>
      </Card>

      <div className="rounded-lg border bg-muted/30 p-4 space-y-2">
        <p className="text-sm font-medium">ইনস্টল করার নিয়ম:</p>
        <ol className="text-sm text-muted-foreground space-y-1 list-decimal list-inside">
          <li>ডাউনলোড বাটনে ক্লিক করুন</li>
          <li>APK ফাইল ডাউনলোড হলে খুলুন</li>
          <li>Settings → Unknown Sources চালু করুন</li>
          <li>ইনস্টল করুন এবং উপভোগ করুন</li>
        </ol>
      </div>
    </div>
  );
}
