import { useEffect, useRef } from "react";
import { useGetVapidPublicKey, useSubscribePush, getGetVapidPublicKeyQueryKey } from "@workspace/api-client-react";

function urlBase64ToUint8Array(base64String: string): ArrayBuffer {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const rawData = atob(base64);
  const outputArray = new Uint8Array(rawData.length);
  for (let i = 0; i < rawData.length; ++i) {
    outputArray[i] = rawData.charCodeAt(i);
  }
  return outputArray.buffer as ArrayBuffer;
}

export function usePushNotifications(enabled: boolean) {
  const { data: vapidData } = useGetVapidPublicKey({
    query: { enabled, queryKey: getGetVapidPublicKeyQueryKey() },
  });
  const subscribePush = useSubscribePush();
  const registered = useRef(false);

  useEffect(() => {
    if (!enabled) return;
    if (!vapidData?.publicKey) return;
    if (registered.current) return;
    if (!("serviceWorker" in navigator) || !("PushManager" in window)) return;

    async function register() {
      try {
        const registration = await navigator.serviceWorker.register("/sw.js", { scope: "/" });
        await navigator.serviceWorker.ready;

        let subscription = await registration.pushManager.getSubscription();

        if (!subscription) {
          const permission = await Notification.requestPermission();
          if (permission !== "granted") return;

          subscription = await registration.pushManager.subscribe({
            userVisibleOnly: true,
            applicationServerKey: urlBase64ToUint8Array(vapidData!.publicKey),
          });
        }

        const json = subscription.toJSON();
        if (!json.endpoint || !json.keys?.p256dh || !json.keys?.auth) return;

        subscribePush.mutate(
          { data: { endpoint: json.endpoint, p256dh: json.keys.p256dh, auth: json.keys.auth } },
        );
        registered.current = true;
      } catch (err) {
        console.warn("Push registration failed:", err);
      }
    }

    register();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [enabled, vapidData?.publicKey]);
}
