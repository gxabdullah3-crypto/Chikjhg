import { ReactNode, useEffect } from "react";
import { Link, useLocation } from "wouter";
import {
  LayoutDashboard,
  CheckSquare,
  ClipboardList,
  Wallet,
  Users,
  LogOut,
  Menu,
  Settings,
  ShieldAlert,
  UserCog,
  Download,
  Headphones,
  MessageCircle,
  TrendingUp,
} from "lucide-react";
import { useGetMe, useLogout, getGetMeQueryKey, useGetSettings, getGetSettingsQueryKey } from "@workspace/api-client-react";
import { useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useToast } from "@/hooks/use-toast";
import { useAppBranding } from "@/hooks/use-app-branding";
import { NotificationBell } from "@/components/notification-bell";
import { usePushNotifications } from "@/hooks/use-push-notifications";

interface LayoutProps {
  children: ReactNode;
}

export function Layout({ children }: LayoutProps) {
  const [location, setLocation] = useLocation();
  const queryClient = useQueryClient();
  const { data: user, isLoading, error } = useGetMe({
    query: { retry: false, queryKey: getGetMeQueryKey() },
  });
  const logout = useLogout();
  const { toast } = useToast();
  const { appName, logoText } = useAppBranding();
  const { data: settings } = useGetSettings({ query: { enabled: !!user, queryKey: getGetSettingsQueryKey() } });

  usePushNotifications(!!user && !isLoading);

  const isAuthRoute = location === "/login" || location === "/register";
  const isAdminRoute = location.startsWith("/admin");
  const isAssistantRoute = location.startsWith("/assistant");

  useEffect(() => {
    if (isLoading) return;
    if (error && !isAuthRoute) { setLocation("/login"); return; }
    if (user) {
      if (isAuthRoute) {
        setLocation(user.role === "admin" ? "/admin" : user.role === "assistant" ? "/assistant/tasks" : "/dashboard");
        return;
      }
      if (isAdminRoute && user.role !== "admin") {
        setLocation(user.role === "assistant" ? "/assistant/tasks" : "/dashboard");
        return;
      }
      if (isAssistantRoute && user.role !== "assistant") {
        setLocation(user.role === "admin" ? "/admin" : "/dashboard");
        return;
      }
      if ((location === "/" || location === "/dashboard") && user.role === "admin") { setLocation("/admin"); return; }
      if ((location === "/" || location === "/dashboard") && user.role === "assistant") { setLocation("/assistant/tasks"); return; }
    }
  }, [user, isLoading, error, location, isAuthRoute, isAdminRoute, setLocation]);

  if (isLoading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="relative">
            <div className="h-12 w-12 animate-spin rounded-full border-4 border-primary/30 border-t-primary" />
            <div className="absolute inset-0 rounded-full" style={{ boxShadow: '0 0 20px rgba(245,158,11,0.3)' }} />
          </div>
          <p className="text-muted-foreground font-medium text-sm">{appName} লোড হচ্ছে...</p>
        </div>
      </div>
    );
  }

  if (!user && !isAuthRoute) return null;
  if (user && isAdminRoute && user.role !== "admin") return null;
  if (user && isAssistantRoute && user.role !== "assistant") return null;

  // Auth pages — no sidebar
  if (isAuthRoute) {
    return <div className="min-h-screen bg-background">{children}</div>;
  }

  const handleLogout = () => {
    logout.mutate(undefined, {
      onSuccess: () => {
        queryClient.setQueryData(getGetMeQueryKey(), null);
        queryClient.clear();
        setLocation("/login");
      },
      onError: () => {
        toast({ title: "লগআউট ব্যর্থ", description: "আবার চেষ্টা করুন।", variant: "destructive" });
      },
    });
  };

  const navItems =
    user?.role === "admin"
      ? [
          { href: "/admin",              label: "ড্যাশবোর্ড",   icon: LayoutDashboard },
          { href: "/admin/tasks",        label: "টাস্ক ম্যানেজ", icon: CheckSquare },
          { href: "/admin/submissions",  label: "সাবমিশন",       icon: ClipboardList },
          { href: "/admin/withdrawals",  label: "উইথড্রয়াল",    icon: Wallet },
          { href: "/admin/users",        label: "ইউজার",          icon: Users },
          { href: "/admin/investments",  label: "বিনিয়োগ পরিকল্পনা", icon: TrendingUp },
          { href: "/admin/assistants",   label: "অ্যাসিস্ট্যান্ট",  icon: UserCog },
          { href: "/admin/settings",     label: "সেটিংস",         icon: Settings },
        ]
      : user?.role === "assistant"
      ? [
          { href: "/assistant/tasks",       label: "আমার টাস্ক",       icon: CheckSquare },
          { href: "/assistant/submissions", label: "সাবমিশন রিভিউ",   icon: ClipboardList },
        ]
      : [
          { href: "/dashboard",  label: "ড্যাশবোর্ড",     icon: LayoutDashboard },
          { href: "/tasks",      label: "টাস্ক করুন",     icon: CheckSquare },
          { href: "/submissions",label: "আমার কাজ",       icon: ClipboardList },
          { href: "/withdraw",   label: "উইথড্রয়াল",      icon: Wallet },
          { href: "/investments", label: "ইনভেস্টমেন্ট", icon: TrendingUp },
          { href: "/referral",   label: "রেফার করুন",     icon: Users },
          { href: "/support",    label: "সাপোর্ট",         icon: Headphones },
          { href: "/download",   label: "অ্যাপ ডাউনলোড",  icon: Download },
        ];

  const currentPage = navItems.find(
    (item) => item.href === location || (item.href !== "/admin" && location.startsWith(item.href)),
  );
  const pageTitle = location.startsWith("/tasks/")
    ? "টাস্কের বিবরণ"
    : currentPage?.label ?? appName;

  const isActive = (href: string) => {
    if (href === "/admin" && location === "/admin") return true;
    if (href !== "/admin" && location.startsWith(href)) return true;
    if (href === "/dashboard" && location === "/dashboard") return true;
    return false;
  };

  const SidebarContent = () => (
    <div className="app-sidebar-inner h-full">
      <Link href={user?.role === "admin" ? "/admin" : user?.role === "assistant" ? "/assistant/tasks" : "/dashboard"}>
        <div className="app-brand cursor-pointer">
          <span className="app-brand-mark">{logoText}</span>
          <span className="min-w-0">
            <span className="app-brand-name block truncate">{appName}</span>
            <span className="app-brand-caption block">Golden Earn</span>
          </span>
        </div>
      </Link>

      <div className="app-nav-caption">Workspace</div>
      <div className="min-h-0 flex-1 overflow-y-auto">
        <nav className="grid gap-1" aria-label="প্রধান নেভিগেশন">
          {navItems.map((item) => {
            const active = isActive(item.href);
            return (
              <Link key={item.href} href={item.href}>
                <span
                  data-testid={`nav-${item.href.replace(/\//g, "-")}`}
                  aria-current={active ? "page" : undefined}
                  className={`app-nav-link cursor-pointer ${active ? "is-active" : ""}`}
                >
                  <item.icon className="h-[17px] w-[17px] flex-shrink-0" strokeWidth={1.8} />
                  <span className="truncate">{item.label}</span>
                </span>
              </Link>
            );
          })}
        </nav>
      </div>

      <div className="app-account-card">
        <div className="flex min-w-0 items-center gap-2.5">
          <span className="app-account-avatar">{user?.name?.trim().charAt(0) || "E"}</span>
          <span className="min-w-0 flex-1">
            <span className="app-account-name block">{user?.name}</span>
            <span className="app-account-email block">{user?.email}</span>
          </span>
        </div>
        {user?.role !== "admin" && (
          <div className="app-account-balance">
            <span>Available balance</span>
            <strong>৳{user?.balance?.toFixed(2) ?? "0.00"}</strong>
          </div>
        )}
        <button
          data-testid="button-logout"
          onClick={handleLogout}
          disabled={logout.isPending}
          className="app-logout"
        >
          <LogOut className="h-4 w-4" />
          {logout.isPending ? "লগআউট হচ্ছে..." : "লগআউট"}
        </button>
      </div>
    </div>
  );

  return (
    <div className="app-shell grid min-h-screen w-full md:grid-cols-[250px_minmax(0,1fr)] xl:grid-cols-[270px_minmax(0,1fr)]">
      <aside className="app-sidebar hidden md:flex">
        <SidebarContent />
      </aside>

      <div className="app-main flex min-h-screen min-w-0 flex-col overflow-hidden">
        <header className="app-topbar">
          <div className="flex min-w-0 items-center gap-3">
            <div className="md:hidden">
              <Sheet>
                <SheetTrigger asChild>
                  <Button variant="outline" size="icon" className="h-9 w-9 rounded-xl border-white/10 bg-white/[.03] text-foreground hover:bg-white/[.08]">
                    <Menu className="h-4 w-4" />
                    <span className="sr-only">মেনু খুলুন</span>
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[280px] border-white/10 bg-[#080e19] p-0 text-foreground">
                  <SidebarContent />
                </SheetContent>
              </Sheet>
            </div>
            <div className="hidden min-w-0 md:block">
              <p className="app-topbar-path">Workspace <strong>{pageTitle}</strong></p>
            </div>
            <div className="app-mobile-brand flex min-w-0 items-center gap-2 md:hidden">
              <span className="app-brand-mark h-8 w-8 rounded-[10px] text-sm">{logoText}</span>
              <span className="truncate text-sm font-semibold text-foreground">{appName}</span>
            </div>
          </div>

          <div className="flex shrink-0 items-center gap-2.5">
            {user?.role === "admin" && (
              <span className="hidden items-center gap-1.5 rounded-full border border-primary/20 bg-primary/[.08] px-2.5 py-1 text-[11px] font-semibold text-primary sm:flex">
                <ShieldAlert className="h-3.5 w-3.5" />
                অ্যাডমিন
              </span>
            )}
            <NotificationBell />
            <div className="app-topbar-user hidden sm:flex">
              <span className="app-account-avatar h-8 w-8 text-xs">{user?.name?.trim().charAt(0) || "E"}</span>
              <span className="hidden min-w-0 lg:block">
                <span className="app-account-name block">{user?.name}</span>
                <span className="app-account-email block">{user?.role === "admin" ? "Administrator" : user?.role}</span>
              </span>
            </div>
          </div>
        </header>

        <main className="app-content flex-1 overflow-auto">
          {children}
        </main>
      </div>

      {user?.role !== "admin" && (settings?.telegramUrl || settings?.whatsappUrl) && (
        <div className="fixed bottom-5 right-4 z-50 flex flex-col items-end gap-2">
          <a
            href={settings?.telegramUrl || settings?.whatsappUrl || "#"}
            target="_blank"
            rel="noreferrer"
            className="support-fab group flex items-center gap-2 rounded-full px-4 py-3 text-sm font-semibold transition-all hover:scale-[1.03] active:scale-95"
          >
            <MessageCircle className="h-5 w-5" />
            সাপোর্ট
          </a>
        </div>
      )}
    </div>
  );
}
