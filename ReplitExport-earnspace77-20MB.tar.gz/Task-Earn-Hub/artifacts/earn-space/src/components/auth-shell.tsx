import type { ReactNode } from "react";
import { useAppBranding } from "@/hooks/use-app-branding";

interface AuthShellProps {
  title: string;
  description: string;
  children: ReactNode;
}

export function AuthShell({ title, description, children }: AuthShellProps) {
  const { appName, logoText } = useAppBranding();

  return (
    <main className="auth-shell">
      <div className="auth-frame">
        <aside className="auth-story">
          <div className="auth-brand-lockup">
            <span className="auth-brand-mark">{logoText}</span>
            <span>
              <span className="auth-brand-name block">{appName}</span>
              <span className="auth-brand-tagline block">আয় করুন, স্বপ্ন পূরণ করুন</span>
            </span>
          </div>

          <div className="auth-story-content">
            <span className="auth-eyebrow">
              <span className="h-1.5 w-1.5 rounded-full bg-primary" />
              Golden Earn
            </span>
            <h1>আপনার পরিশ্রম, আপনার অগ্রগতি</h1>
            <p>টাস্ক, আয় এবং বিনিয়োগ—আপনার Earn Space অ্যাকাউন্টে একসাথে।</p>
          </div>

          <p className="auth-story-footer">কাজ · আয় · অগ্রগতি</p>
        </aside>

        <section className="auth-panel">
          <div className="auth-panel-brand auth-brand-lockup">
            <span className="auth-brand-mark">{logoText}</span>
            <span>
              <span className="auth-brand-name block">{appName}</span>
              <span className="auth-brand-tagline block">আয় করুন, স্বপ্ন পূরণ করুন</span>
            </span>
          </div>

          <div className="auth-panel-heading">
            <span className="auth-eyebrow">GOLDEN EARN</span>
            <h2>{title}</h2>
            <p>{description}</p>
          </div>

          {children}
          <p className="auth-panel-footer">Earn Space · আপনার অগ্রগতির জায়গা</p>
        </section>
      </div>
    </main>
  );
}