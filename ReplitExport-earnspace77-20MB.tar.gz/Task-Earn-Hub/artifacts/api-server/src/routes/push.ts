import { Router } from "express";
import webpush from "web-push";
import { db, pushSubscriptionsTable, usersTable } from "@workspace/db";
import { eq } from "drizzle-orm";
import { SubscribePushBody } from "@workspace/api-zod";
import { requireAuth } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const VAPID_PUBLIC_KEY = process.env.VAPID_PUBLIC_KEY!;
const VAPID_PRIVATE_KEY = process.env.VAPID_PRIVATE_KEY!;
const VAPID_SUBJECT = process.env.VAPID_SUBJECT || "mailto:admin@earnspace.app";

if (VAPID_PUBLIC_KEY && VAPID_PRIVATE_KEY) {
  webpush.setVapidDetails(VAPID_SUBJECT, VAPID_PUBLIC_KEY, VAPID_PRIVATE_KEY);
}

const router = Router();

router.get("/push/vapid-public-key", (req, res) => {
  return res.json({ publicKey: VAPID_PUBLIC_KEY || "" });
});

router.post("/push/subscribe", requireAuth, async (req, res) => {
  const parsed = SubscribePushBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const user = req.currentUser!;
    const { endpoint, p256dh, auth } = parsed.data;

    // Upsert subscription — one per endpoint
    const existing = await db.select().from(pushSubscriptionsTable)
      .where(eq(pushSubscriptionsTable.endpoint, endpoint));

    if (existing.length > 0) {
      await db.update(pushSubscriptionsTable)
        .set({ userId: user.id, p256dh, auth })
        .where(eq(pushSubscriptionsTable.endpoint, endpoint));
    } else {
      await db.insert(pushSubscriptionsTable).values({ userId: user.id, endpoint, p256dh, auth });
    }

    return res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "Push subscribe error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export async function sendPushToUser(userId: number, title: string, body: string, url = "/") {
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) return;
  try {
    const subs = await db.select().from(pushSubscriptionsTable)
      .where(eq(pushSubscriptionsTable.userId, userId));

    const payload = JSON.stringify({ title, body, url });

    for (const sub of subs) {
      try {
        await webpush.sendNotification(
          { endpoint: sub.endpoint, keys: { p256dh: sub.p256dh, auth: sub.auth } },
          payload
        );
      } catch (err: unknown) {
        // Remove expired/invalid subscriptions
        const errAny = err as { statusCode?: number };
        if (errAny?.statusCode === 410 || errAny?.statusCode === 404) {
          await db.delete(pushSubscriptionsTable).where(eq(pushSubscriptionsTable.id, sub.id));
        } else {
          logger.error({ err }, "Send push failed");
        }
      }
    }
  } catch (err) {
    logger.error({ err }, "sendPushToUser error");
  }
}

export async function sendPushToAdmins(title: string, body: string, url = "/admin") {
  if (!VAPID_PUBLIC_KEY || !VAPID_PRIVATE_KEY) return;
  try {
    const admins = await db.select().from(usersTable).where(eq(usersTable.role, "admin"));
    for (const admin of admins) {
      await sendPushToUser(admin.id, title, body, url);
    }
  } catch (err) {
    logger.error({ err }, "sendPushToAdmins error");
  }
}

export default router;
