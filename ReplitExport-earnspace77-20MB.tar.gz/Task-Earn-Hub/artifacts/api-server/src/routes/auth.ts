import { Router } from "express";
import bcrypt from "bcrypt";
import { db, usersTable, appSettingsTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import { v4 as uuidv4 } from "uuid";
import { RegisterBody, LoginBody } from "@workspace/api-zod";
import { logger } from "../lib/logger";

const router = Router();

function formatUser(user: typeof usersTable.$inferSelect) {
  return {
    id: user.id,
    name: user.name,
    email: user.email,
    phone: user.phone ?? null,
    role: user.role,
    status: user.status,
    balance: Number(user.balance),
    investmentBalance: Number(user.investmentBalance),
    referralCode: user.referralCode,
    referredBy: user.referredBy ?? null,
    createdAt: user.createdAt.toISOString(),
  };
}

router.post("/auth/register", async (req, res) => {
  const parsed = RegisterBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input", details: parsed.error.errors });
  }

  const { name, email, password, phone, referralCode: refCode } = parsed.data;

  try {
    const existing = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (existing.length > 0) {
      return res.status(400).json({ error: "Email already registered" });
    }

    const totalUsersResult = await db.select({ count: count() }).from(usersTable);
    const totalUsers = Number(totalUsersResult[0]?.count ?? 0);
    const isFirstUser = totalUsers === 0;

    const hashedPassword = await bcrypt.hash(password, 12);
    const myReferralCode = uuidv4().slice(0, 8).toUpperCase();

    let referredByCode: string | null = null;
    if (refCode && !isFirstUser) {
      const referrer = await db.select().from(usersTable).where(eq(usersTable.referralCode, refCode));
      if (referrer.length > 0) {
        referredByCode = refCode;
      }
    }

    const [newUser] = await db.insert(usersTable).values({
      name,
      email,
      password: hashedPassword,
      phone: phone || null,
      role: isFirstUser ? "admin" : "user",
      referralCode: myReferralCode,
      referredBy: referredByCode,
    }).returning();

    if (!newUser) return res.status(500).json({ error: "Failed to create user" });

    // Ensure default settings exist
    if (isFirstUser) {
      const settingsCount = await db.select({ count: count() }).from(appSettingsTable);
      if (Number(settingsCount[0]?.count ?? 0) === 0) {
        await db.insert(appSettingsTable).values({ referralCommissionPercent: "5", minWithdrawal: "50" });
      }
    }

    req.session.userId = newUser.id;
    await new Promise<void>((resolve, reject) => req.session.save((err) => err ? reject(err) : resolve()));

    return res.status(201).json(formatUser(newUser));
  } catch (err) {
    logger.error({ err }, "Register error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/auth/login", async (req, res) => {
  const parsed = LoginBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input" });
  }

  const { email, password } = parsed.data;

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.email, email));
    if (!user) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) {
      return res.status(401).json({ error: "Invalid email or password" });
    }

    req.session.userId = user.id;
    await new Promise<void>((resolve, reject) => req.session.save((err) => err ? reject(err) : resolve()));

    return res.status(200).json(formatUser(user));
  } catch (err) {
    logger.error({ err }, "Login error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/auth/logout", (req, res) => {
  req.session.destroy((err) => {
    if (err) logger.error({ err }, "Logout error");
    res.clearCookie("connect.sid");
    return res.status(200).json({ ok: true });
  });
});

router.get("/auth/me", async (req, res) => {
  const userId = req.session?.userId;
  if (!userId) {
    return res.status(401).json({ error: "Unauthorized" });
  }

  try {
    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, userId));
    if (!user) {
      req.session.destroy(() => {});
      return res.status(401).json({ error: "User not found" });
    }
    return res.status(200).json(formatUser(user));
  } catch (err) {
    logger.error({ err }, "Get me error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
