import { Router } from "express";
import { db, tasksTable, submissionsTable, assistantActivityTable } from "@workspace/db";
import { eq, count } from "drizzle-orm";
import { CreateTaskBody, UpdateTaskBody, GetTaskParams, UpdateTaskParams, DeleteTaskParams } from "@workspace/api-zod";
import { requireAuth, requireAdminOrAssistant } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router = Router();

function formatTask(task: typeof tasksTable.$inferSelect) {
  return {
    id: task.id,
    title: task.title,
    description: task.description,
    reward: Number(task.reward),
    link: task.link ?? null,
    status: task.status,
    createdBy: task.createdBy ?? null,
    createdAt: task.createdAt.toISOString(),
  };
}

function canManageTask(user: NonNullable<Express.Request["currentUser"]>, task: typeof tasksTable.$inferSelect) {
  return user.role === "admin" || (user.role === "assistant" && task.createdBy === user.id);
}

router.get("/tasks", requireAuth, async (req, res) => {
  try {
    const { status } = req.query as { status?: string };
    let tasks = await db.select().from(tasksTable).orderBy(tasksTable.createdAt);
    if (req.currentUser?.role === "assistant") {
      tasks = tasks.filter((t) => t.createdBy === req.currentUser!.id);
    }
    if (status) {
      tasks = tasks.filter((t) => t.status === status);
    }
    return res.json(tasks.map(formatTask));
  } catch (err) {
    logger.error({ err }, "List tasks error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/tasks", requireAuth, requireAdminOrAssistant, async (req, res) => {
  const parsed = CreateTaskBody.safeParse(req.body);
  if (!parsed.success) {
    return res.status(400).json({ error: "Invalid input", details: parsed.error.errors });
  }
  try {
    const task = await db.transaction(async (tx) => {
      const [created] = await tx.insert(tasksTable).values({
        title: parsed.data.title,
        description: parsed.data.description,
        reward: String(parsed.data.reward),
        link: parsed.data.link ?? null,
        status: (parsed.data.status as "active" | "inactive") ?? "active",
        createdBy: req.currentUser!.id,
      }).returning();
      if (!created) return undefined;
      if (req.currentUser!.role === "assistant") {
        await tx.insert(assistantActivityTable).values({
          assistantId: req.currentUser!.id,
          action: "task_created",
          taskId: created.id,
          details: created.title,
        });
      }
      return created;
    });
    if (!task) return res.status(500).json({ error: "Failed to create task" });
    return res.status(201).json(formatTask(task));
  } catch (err) {
    logger.error({ err }, "Create task error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.get("/tasks/:id", requireAuth, async (req, res) => {
  const parsed = GetTaskParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  try {
    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, parsed.data.id));
    if (!task) return res.status(404).json({ error: "Task not found" });
    if (req.currentUser?.role === "assistant" && task.createdBy !== req.currentUser.id) {
      return res.status(403).json({ error: "You can only access your own tasks" });
    }
    return res.json(formatTask(task));
  } catch (err) {
    logger.error({ err }, "Get task error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/tasks/:id", requireAuth, requireAdminOrAssistant, async (req, res) => {
  const paramsParsed = UpdateTaskParams.safeParse({ id: Number(req.params.id) });
  if (!paramsParsed.success) return res.status(400).json({ error: "Invalid id" });
  const bodyParsed = UpdateTaskBody.safeParse(req.body);
  if (!bodyParsed.success) return res.status(400).json({ error: "Invalid input" });
  try {
    const [existingTask] = await db.select().from(tasksTable).where(eq(tasksTable.id, paramsParsed.data.id));
    if (!existingTask) return res.status(404).json({ error: "Task not found" });
    if (!canManageTask(req.currentUser!, existingTask)) {
      return res.status(403).json({ error: "You can only manage your own tasks" });
    }
    const updates: Partial<typeof tasksTable.$inferInsert> = {};
    if (bodyParsed.data.title !== undefined) updates.title = bodyParsed.data.title;
    if (bodyParsed.data.description !== undefined) updates.description = bodyParsed.data.description;
    if (bodyParsed.data.reward !== undefined) updates.reward = String(bodyParsed.data.reward);
    if (bodyParsed.data.link !== undefined) updates.link = bodyParsed.data.link ?? null;
    if (bodyParsed.data.status !== undefined) updates.status = bodyParsed.data.status as "active" | "inactive";

    const task = await db.transaction(async (tx) => {
      const [updated] = await tx.update(tasksTable)
        .set(updates)
        .where(eq(tasksTable.id, paramsParsed.data.id))
        .returning();
      if (!updated) return undefined;
      if (req.currentUser!.role === "assistant") {
        await tx.insert(assistantActivityTable).values({
          assistantId: req.currentUser!.id,
          action: "task_updated",
          taskId: updated.id,
          details: updated.title,
        });
      }
      return updated;
    });
    if (!task) return res.status(404).json({ error: "Task not found" });
    return res.json(formatTask(task));
  } catch (err) {
    logger.error({ err }, "Update task error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.delete("/tasks/:id", requireAuth, requireAdminOrAssistant, async (req, res) => {
  const parsed = DeleteTaskParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });
  try {
    const [task] = await db.select().from(tasksTable).where(eq(tasksTable.id, parsed.data.id));
    if (!task) return res.status(404).json({ error: "Task not found" });
    if (!canManageTask(req.currentUser!, task)) {
      return res.status(403).json({ error: "You can only manage your own tasks" });
    }
    const deleted = await db.transaction(async (tx) => {
      const [submissionSummary] = await tx.select({ count: count() })
        .from(submissionsTable)
        .where(eq(submissionsTable.taskId, task.id));
      if (Number(submissionSummary?.count ?? 0) > 0) return false;
      await tx.delete(tasksTable).where(eq(tasksTable.id, parsed.data.id));
      if (req.currentUser!.role === "assistant") {
        await tx.insert(assistantActivityTable).values({
          assistantId: req.currentUser!.id,
          action: "task_deleted",
          taskId: task.id,
          details: task.title,
        });
      }
      return true;
    });
    if (!deleted) {
      return res.status(409).json({ error: "Tasks with submissions cannot be deleted. Set the task to inactive instead." });
    }
    return res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "Delete task error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
