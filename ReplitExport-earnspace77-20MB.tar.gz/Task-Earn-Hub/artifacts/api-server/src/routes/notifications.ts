import { Router } from "express";
import { db, notificationsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";

const router = Router();

function formatNotification(n: typeof notificationsTable.$inferSelect) {
  return {
    id: n.id,
    userId: n.userId,
    message: n.message,
    type: n.type,
    read: n.read,
    createdAt: n.createdAt.toISOString(),
  };
}

router.get("/notifications", requireAuth, async (req, res) => {
  try {
    const user = req.currentUser!;
    const rows = await db
      .select()
      .from(notificationsTable)
      .where(eq(notificationsTable.userId, user.id))
      .orderBy(desc(notificationsTable.createdAt))
      .limit(50);
    return res.json(rows.map(formatNotification));
  } catch (err) {
    logger.error({ err }, "List notifications error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/notifications/read-all", requireAuth, async (req, res) => {
  try {
    const user = req.currentUser!;
    await db
      .update(notificationsTable)
      .set({ read: true })
      .where(eq(notificationsTable.userId, user.id));
    return res.json({ ok: true });
  } catch (err) {
    logger.error({ err }, "Mark all read error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/notifications/:id/read", requireAuth, async (req, res) => {
  const id = Number(req.params.id);
  if (!id) return res.status(400).json({ error: "Invalid id" });
  try {
    const user = req.currentUser!;
    const [updated] = await db
      .update(notificationsTable)
      .set({ read: true })
      .where(eq(notificationsTable.id, id))
      .returning();
    if (!updated || updated.userId !== user.id) {
      return res.status(404).json({ error: "Notification not found" });
    }
    return res.json(formatNotification(updated));
  } catch (err) {
    logger.error({ err }, "Mark notification read error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
