import { Router } from "express";
import { db, withdrawalsTable, usersTable, appSettingsTable, notificationsTable } from "@workspace/db";
import { eq, and, count } from "drizzle-orm";
import {
  RequestWithdrawalBody,
  ApproveWithdrawalParams,
  RejectWithdrawalParams,
  RejectWithdrawalBody,
} from "@workspace/api-zod";
import { requireAuth, requireAdmin } from "../middlewares/requireAuth";
import { logger } from "../lib/logger";
import { sendPushToUser, sendPushToAdmins } from "./push";
import { centsToDecimal, decimalToCents } from "../lib/money";
import { WalletMutationError, applyWalletEntry } from "../lib/wallet-ledger";

const router = Router();

function formatUser(u: typeof usersTable.$inferSelect) {
  return { id: u.id, name: u.name, email: u.email, phone: u.phone ?? null, role: u.role, status: u.status, balance: Number(u.balance), investmentBalance: Number(u.investmentBalance), referralCode: u.referralCode, createdAt: u.createdAt.toISOString() };
}
function formatWithdrawal(w: typeof withdrawalsTable.$inferSelect, user?: typeof usersTable.$inferSelect) {
  return {
    id: w.id,
    userId: w.userId,
    amount: Number(w.amount),
    method: w.method,
    accountNumber: w.accountNumber,
    status: w.status,
    rejectionReason: w.rejectionReason ?? null,
    createdAt: w.createdAt.toISOString(),
    user: user ? formatUser(user) : undefined,
  };
}

async function createNotification(userId: number, message: string, type: "success" | "error" | "info") {
  try {
    await db.insert(notificationsTable).values({ userId, message, type });
  } catch (err) {
    logger.error({ err }, "Failed to create notification");
  }
}

router.get("/withdrawals", requireAuth, async (req, res) => {
  try {
    const { status } = req.query as { status?: string };
    const user = req.currentUser!;

    const rows = await db.select().from(withdrawalsTable)
      .leftJoin(usersTable, eq(withdrawalsTable.userId, usersTable.id))
      .orderBy(withdrawalsTable.createdAt);

    const filtered = rows.filter((r) => {
      if (user.role !== "admin" && r.withdrawals.userId !== user.id) return false;
      if (status && r.withdrawals.status !== status) return false;
      return true;
    });

    return res.json(filtered.map((r) => formatWithdrawal(r.withdrawals, r.users ?? undefined)));
  } catch (err) {
    logger.error({ err }, "List withdrawals error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.post("/withdrawals", requireAuth, async (req, res) => {
  const parsed = RequestWithdrawalBody.safeParse(req.body);
  if (!parsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const user = req.currentUser!;
    const amount = parsed.data.amount;

    // Require at least 5 direct referrals before first withdrawal
    const [referralRow] = await db.select({ cnt: count() }).from(usersTable)
      .where(and(
        eq(usersTable.referredBy, user.referralCode),
        eq(usersTable.status, "active"),
      ));
    const directReferrals = Number(referralRow?.cnt ?? 0);
    if (directReferrals < 5) {
      return res.status(403).json({
        error: `উইথড্রয়াল করতে কমপক্ষে ৫ জন রেফার করতে হবে। আপনি এখন পর্যন্ত ${directReferrals} জন রেফার করেছেন।`,
        code: "REFERRAL_REQUIRED",
        currentReferrals: directReferrals,
        requiredReferrals: 5,
      });
    }

    const settingsRows = await db.select().from(appSettingsTable);
    const settings = settingsRows[0];
    const minWithdrawal = settings ? Number(settings.minWithdrawal) : 50;

    if (amount < minWithdrawal) {
      return res.status(400).json({ error: `Minimum withdrawal is ${minWithdrawal} BDT` });
    }

    const method = parsed.data.method as "bkash" | "nagad";
    const amountDecimal = centsToDecimal(decimalToCents(amount));
    const withdrawal = await db.transaction(async (tx) => {
      const [created] = await tx.insert(withdrawalsTable).values({
        userId: user.id,
        amount: amountDecimal,
        method,
        accountNumber: parsed.data.accountNumber,
      }).returning();
      if (!created) throw new Error("Failed to create withdrawal request");
      await applyWalletEntry(tx, {
        userId: user.id,
        wallet: "main",
        transactionType: "withdrawal_debit",
        amount: `-${amountDecimal}`,
        description: `উইথড্রয়াল অনুরোধ #${created.id}`,
        idempotencyKey: `withdrawal:request:${created.id}`,
        referenceId: created.id,
      });
      return created;
    });

    if (!withdrawal) return res.status(500).json({ error: "Failed to create withdrawal request" });

    // Notify admins about new withdrawal request
    const methodLabel = method === "bkash" ? "bKash" : "Nagad";
    sendPushToAdmins(
      "নতুন উইথড্রয়াল অনুরোধ 💰",
      `${user.name} — ৳${amount.toFixed(2)} BDT ${methodLabel} (${parsed.data.accountNumber}) উইথড্রয়াল করতে চান।`,
      "/admin/withdrawals"
    ).catch(() => {});

    const [updatedUser] = await db.select().from(usersTable).where(eq(usersTable.id, user.id));
    return res.status(201).json(formatWithdrawal(withdrawal, updatedUser));
  } catch (err) {
    if (err instanceof WalletMutationError && err.code === "INSUFFICIENT_BALANCE") {
      return res.status(400).json({ error: "Insufficient balance" });
    }
    logger.error({ err }, "Request withdrawal error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/withdrawals/:id/approve", requireAuth, requireAdmin, async (req, res) => {
  const parsed = ApproveWithdrawalParams.safeParse({ id: Number(req.params.id) });
  if (!parsed.success) return res.status(400).json({ error: "Invalid id" });

  try {
    const [updated] = await db.update(withdrawalsTable)
      .set({ status: "approved" })
      .where(and(
        eq(withdrawalsTable.id, parsed.data.id),
        eq(withdrawalsTable.status, "pending"),
      ))
      .returning();
    if (!updated) {
      const [existing] = await db.select({ id: withdrawalsTable.id }).from(withdrawalsTable)
        .where(eq(withdrawalsTable.id, parsed.data.id));
      return res.status(existing ? 409 : 404).json({ error: existing ? "Withdrawal has already been reviewed" : "Withdrawal not found" });
    }

    const [user] = await db.select().from(usersTable).where(eq(usersTable.id, updated.userId));
    const methodLabel = updated.method === "bkash" ? "bKash" : "Nagad";
    const msg = `আপনার ৳${Number(updated.amount).toFixed(2)} BDT উইথড্রয়াল অনুমোদিত হয়েছে। ${methodLabel} নম্বরে পাঠানো হবে।`;

    createNotification(updated.userId, msg, "success").catch(() => {});
    sendPushToUser(updated.userId, "উইথড্রয়াল অনুমোদিত! ✅", msg, "/withdraw").catch(() => {});

    return res.json(formatWithdrawal(updated, user));
  } catch (err) {
    logger.error({ err }, "Approve withdrawal error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

router.patch("/withdrawals/:id/reject", requireAuth, requireAdmin, async (req, res) => {
  const paramsParsed = RejectWithdrawalParams.safeParse({ id: Number(req.params.id) });
  const bodyParsed = RejectWithdrawalBody.safeParse(req.body);
  if (!paramsParsed.success || !bodyParsed.success) return res.status(400).json({ error: "Invalid input" });

  try {
    const updated = await db.transaction(async (tx) => {
      const [changed] = await tx.update(withdrawalsTable)
        .set({ status: "rejected", rejectionReason: bodyParsed.data.reason })
        .where(and(
          eq(withdrawalsTable.id, paramsParsed.data.id),
          eq(withdrawalsTable.status, "pending"),
        ))
        .returning();
      if (!changed) return undefined;
      const amount = centsToDecimal(decimalToCents(changed.amount));
      await applyWalletEntry(tx, {
        userId: changed.userId,
        wallet: "main",
        transactionType: "withdrawal_refund",
        amount,
        description: `উইথড্রয়াল #${changed.id} ফেরত`,
        idempotencyKey: `withdrawal:refund:${changed.id}`,
        referenceId: changed.id,
      });
      return changed;
    });
    if (!updated) {
      const [existing] = await db.select({ id: withdrawalsTable.id }).from(withdrawalsTable)
        .where(eq(withdrawalsTable.id, paramsParsed.data.id));
      return res.status(existing ? 409 : 404).json({ error: existing ? "Withdrawal has already been reviewed" : "Withdrawal not found" });
    }

    const msg = `আপনার ৳${Number(updated.amount).toFixed(2)} BDT উইথড্রয়াল প্রত্যাখ্যাত। কারণ: ${bodyParsed.data.reason}। টাকা ফেরত দেওয়া হয়েছে।`;
    createNotification(updated.userId, msg, "error").catch(() => {});
    sendPushToUser(updated.userId, "উইথড্রয়াল প্রত্যাখ্যাত ❌", msg, "/withdraw").catch(() => {});

    const [updatedUser] = await db.select().from(usersTable).where(eq(usersTable.id, updated.userId));
    return res.json(formatWithdrawal(updated, updatedUser));
  } catch (err) {
    logger.error({ err }, "Reject withdrawal error");
    return res.status(500).json({ error: "Internal server error" });
  }
});

export default router;
