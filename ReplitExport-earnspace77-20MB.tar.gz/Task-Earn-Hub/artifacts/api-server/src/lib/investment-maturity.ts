import { and, asc, eq, lte } from "drizzle-orm";
import {
  db,
  investmentsTable,
  notificationsTable,
} from "@workspace/db";
import { logger } from "./logger";
import { applyWalletEntry } from "./wallet-ledger";

let processorRunning = false;
let timer: NodeJS.Timeout | undefined;

export async function settleMaturedInvestments(userId?: number): Promise<number> {
  const now = new Date();
  const conditions = [
    eq(investmentsTable.status, "active"),
    lte(investmentsTable.maturityAt, now),
  ];
  if (userId !== undefined) conditions.push(eq(investmentsTable.userId, userId));

  const due = await db.select().from(investmentsTable)
    .where(and(...conditions))
    .orderBy(asc(investmentsTable.maturityAt))
    .limit(100);

  let settledCount = 0;
  for (const candidate of due) {
    try {
      const settled = await db.transaction(async (tx) => {
        const [investment] = await tx.update(investmentsTable)
          .set({ status: "matured", settledAt: now })
          .where(and(
            eq(investmentsTable.id, candidate.id),
            eq(investmentsTable.status, "active"),
            lte(investmentsTable.maturityAt, now),
          ))
          .returning();
        if (!investment) return false;

        await applyWalletEntry(tx, {
          userId: investment.userId,
          wallet: "main",
          transactionType: "investment_maturity",
          amount: investment.totalReturn,
          description: `${investment.planTitle} মেয়াদপূর্তি: মূলধন ও লাভ জমা`,
          idempotencyKey: `investment:maturity:main:${investment.id}`,
          referenceId: investment.id,
        });
        await applyWalletEntry(tx, {
          userId: investment.userId,
          wallet: "investment",
          transactionType: "investment_maturity_unlock",
          amount: `-${investment.principal}`,
          description: `${investment.planTitle} মেয়াদপূর্তি: লক করা মূলধন মুক্ত`,
          idempotencyKey: `investment:maturity:locked:${investment.id}`,
          referenceId: investment.id,
        });
        await tx.insert(notificationsTable).values({
          userId: investment.userId,
          type: "success",
          message: `${investment.planTitle} ইনভেস্টমেন্টের মেয়াদ শেষ হয়েছে। ৳${Number(investment.totalReturn).toFixed(2)} BDT আপনার মূল ব্যালেন্সে জমা হয়েছে।`,
        });
        return true;
      });
      if (settled) settledCount += 1;
    } catch (err) {
      logger.error({ err, investmentId: candidate.id }, "Investment maturity settlement failed");
    }
  }

  return settledCount;
}

export function startInvestmentMaturityProcessor() {
  if (timer) return;
  const run = async () => {
    if (processorRunning) return;
    processorRunning = true;
    try {
      const settled = await settleMaturedInvestments();
      if (settled > 0) logger.info({ settled }, "Matured investments settled");
    } catch (err) {
      logger.error({ err }, "Investment maturity processor failed");
    } finally {
      processorRunning = false;
    }
  };
  void run();
  timer = setInterval(() => void run(), 60_000);
  timer.unref();
}

export function stopInvestmentMaturityProcessor() {
  if (!timer) return;
  clearInterval(timer);
  timer = undefined;
}