import React from 'react';
import { Mail, Lock, ArrowRight } from 'lucide-react';

export default function GoldenEarn() {
  return (
    <div className="relative min-h-screen w-full sm:w-[390px] mx-auto overflow-hidden bg-gradient-to-b from-[#060D1F] via-[#0B1630] to-[#0F1D3E] font-['Poppins',sans-serif] flex flex-col items-center justify-center p-6 text-white">
      {/* custom styles */}
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap');
        
        .coin-logo {
          animation: coin-spin 3s ease-in-out infinite;
          transform-style: preserve-3d;
        }
        
        .coin-glow {
          animation: pulse-glow 2s ease-in-out infinite;
        }

        .star-float-1 { animation: float 4s ease-in-out infinite; }
        .star-float-2 { animation: float 5s ease-in-out infinite 1s; }
        .star-float-3 { animation: float 6s ease-in-out infinite 2s; }
        .star-float-4 { animation: float 5.5s ease-in-out infinite 0.5s; }
        .star-float-5 { animation: float 4.5s ease-in-out infinite 1.5s; }

        @keyframes coin-spin {
          0% { transform: rotateY(0deg); }
          50% { transform: rotateY(180deg); }
          100% { transform: rotateY(360deg); }
        }

        @keyframes pulse-glow {
          0%, 100% { box-shadow: 0 0 20px rgba(245, 158, 11, 0.4); }
          50% { box-shadow: 0 0 40px rgba(245, 158, 11, 0.8); }
        }

        @keyframes float {
          0%, 100% { transform: translateY(0) scale(1); opacity: 0.3; }
          50% { transform: translateY(-20px) scale(1.2); opacity: 0.8; }
        }
      `}</style>

      {/* Background Decorative Stars */}
      <div className="absolute top-[15%] left-[10%] w-2 h-2 rounded-full bg-[#F59E0B] star-float-1 shadow-[0_0_8px_#F59E0B]" />
      <div className="absolute top-[25%] right-[15%] w-1.5 h-1.5 rounded-full bg-[#FEF3C7] star-float-2 shadow-[0_0_6px_#FEF3C7]" />
      <div className="absolute top-[60%] left-[8%] w-1 h-1 rounded-full bg-[#D97706] star-float-3 shadow-[0_0_4px_#D97706]" />
      <div className="absolute bottom-[20%] right-[10%] w-2 h-2 rounded-full bg-[#F59E0B] star-float-4 shadow-[0_0_8px_#F59E0B]" />
      <div className="absolute bottom-[10%] left-[20%] w-1.5 h-1.5 rounded-full bg-[#FEF3C7] star-float-5 shadow-[0_0_6px_#FEF3C7]" />

      <div className="z-10 flex flex-col items-center w-full">
        {/* Logo Section */}
        <div className="mb-10 flex flex-col items-center">
          <div className="relative mb-6">
            <div className="absolute inset-0 bg-[#F59E0B] rounded-full blur-xl opacity-30 coin-glow"></div>
            <div className="relative w-24 h-24 rounded-full border-4 border-[#F59E0B] bg-gradient-to-br from-[#F59E0B] to-[#D97706] flex items-center justify-center coin-logo shadow-[inset_0_0_15px_rgba(255,255,255,0.4)]">
              <span className="text-4xl font-bold text-[#060D1F] transform translate-z-[20px]">E</span>
              <div className="absolute inset-2 rounded-full border border-[rgba(255,255,255,0.3)]"></div>
            </div>
          </div>
          <h1 className="text-3xl font-bold tracking-[0.2em] text-[#F59E0B] mb-2 uppercase drop-shadow-[0_2px_4px_rgba(0,0,0,0.5)]">
            Earn Space
          </h1>
          <p className="text-[#D97706] text-sm tracking-wide font-medium">
            আয় করুন, স্বপ্ন পূরণ করুন
          </p>
        </div>

        {/* Login Form */}
        <div className="w-full bg-[rgba(255,255,255,0.05)] backdrop-blur-md border border-[rgba(245,158,11,0.3)] rounded-3xl p-6 shadow-2xl relative overflow-hidden">
          {/* subtle flare on card */}
          <div className="absolute top-0 left-0 w-full h-1/2 bg-gradient-to-b from-[rgba(245,158,11,0.05)] to-transparent pointer-events-none"></div>

          <div className="flex flex-col gap-5 mb-8">
            <div className="flex flex-col gap-1.5">
              <label className="text-[#FEF3C7] text-xs ml-1 font-medium tracking-wide">ইমেইল</label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Mail className="w-5 h-5 text-[#F59E0B] opacity-70 group-focus-within:opacity-100 transition-opacity" />
                </div>
                <input
                  type="email"
                  placeholder="আপনার ইমেইল লিখুন"
                  className="w-full bg-[rgba(255,255,255,0.07)] text-white placeholder-[rgba(254,243,199,0.4)] rounded-xl py-3.5 pl-11 pr-4 outline-none border border-transparent focus:border-[#F59E0B] focus:bg-[rgba(255,255,255,0.1)] transition-all shadow-inner text-sm"
                />
              </div>
            </div>

            <div className="flex flex-col gap-1.5">
              <label className="text-[#FEF3C7] text-xs ml-1 font-medium tracking-wide flex justify-between">
                <span>পাসওয়ার্ড</span>
                <a href="#" className="text-[#F59E0B] hover:text-[#FEF3C7] transition-colors">ভুলে গেছেন?</a>
              </label>
              <div className="relative group">
                <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
                  <Lock className="w-5 h-5 text-[#F59E0B] opacity-70 group-focus-within:opacity-100 transition-opacity" />
                </div>
                <input
                  type="password"
                  placeholder="আপনার পাসওয়ার্ড লিখুন"
                  className="w-full bg-[rgba(255,255,255,0.07)] text-white placeholder-[rgba(254,243,199,0.4)] rounded-xl py-3.5 pl-11 pr-4 outline-none border border-transparent focus:border-[#F59E0B] focus:bg-[rgba(255,255,255,0.1)] transition-all shadow-inner text-sm"
                />
              </div>
            </div>
          </div>

          <button className="w-full bg-gradient-to-r from-[#F59E0B] to-[#FACC15] hover:from-[#D97706] hover:to-[#F59E0B] text-[#060D1F] font-bold text-base py-3.5 rounded-xl shadow-[0_4px_15px_rgba(245,158,11,0.4)] transition-all transform hover:scale-[1.02] active:scale-[0.98] flex items-center justify-center gap-2 group">
            লগইন করুন
            <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>

        <div className="mt-8 text-center z-10">
          <p className="text-sm text-[rgba(254,243,199,0.6)]">
            অ্যাকাউন্ট নেই?{' '}
            <a href="#" className="text-[#D97706] font-semibold hover:text-[#F59E0B] transition-colors">
              রেজিস্টার করুন
            </a>
          </p>
        </div>
      </div>
    </div>
  );
}
